function ClassProject()
{

	//properties of project
	var uname;
	var jname;
	var url;
	var branch;
	var email;
	var language;
	var minute;
	var day;
	var hours;
	var weekday;
	var month;
	//method for set Project Details
	this.setProjectData = function(uname,jname,url,branch,email,language)
	{
		this.uname=uname;
		this.jname=jname;
		this.url=url;
		this.branch=branch;
		this.email=email;
		this.language=language;
	}
	//method for set Project Schedule
	this.setProjectSchedule = function(minute,day,hours,weekday,month)
	{
		this.minute=minute;
		this.day=day;
		this.hours=hours;
		this.weekday=weekday;
		this. month=month;
	}
	//method for add or edit project form
	this.formProject = function(actmode,c){

		var parsedTemplate ='';
		var exampleValues = '';
		
		//console.log('Class');
					$.ajax({
						url:'/Code_Quality_Analysis/add_new_job.html',
						type:'GET',
						async: true,
						success: function(json) {

							parsedTemplate = _.template(json);
							exampleValues = parsedTemplate({act:actmode,id:c});
							document.getElementById('output_div').innerHTML=exampleValues;
							
							}
						});

	}

	//method for save or update project
	this.saveProject = function(){

		var formData = JSON.stringify({"uname":this.uname,"jname":this.jname,"url":this.url,"branch":this.branch,"email":this.email,"language":this.language,"minute":this.minute,"day":this.day,"hours":this.hours,"weekday":this.weekday,"month":this.month});
		
		
					$.ajax({
					    url: 'http://10.71.71.18:5000/todo/api/v1.0/tasks',
						dataType: 'json',
						type: 'post',
						contentType: 'application/json',
						data: formData,
						success: function(json) {

							console.log('Class success');
							$('#myModal').modal('show');
							
							},
				        error: function( jqXhr, textStatus, errorThrown ){
							//console.log("error");
							document.getElementById('output_div').innerHTML='<div class="alert alert-danger"><strong>Error!</strong> Internal API Error.</div>';
						}
					
					});
	}

    this.listProject = function(){

			var usname = localStorage.getItem("username");
			var start = localStorage.getItem("page_start");
			var size = localStorage.getItem("page_size");;
			console.log(start+":"+size);
		    var formData = JSON.stringify({ "username" : usname,"start": start,"size": size});
		
				$.ajax({
				   url: 'http://10.71.71.18:5000/todo/api/v1.0/list',
				   dataType: 'json',
				   type: 'post',
				   contentType: 'application/json',
				   data: formData,

				   success: function( response ){
					   //console.log("success");
					  
					   //console.log(response);
					   
						$.ajax({
						url:'/Code_Quality_Analysis/view_list_jobs.html',
						type:'GET',
						async: false,
						success: function(json) {
							
							parsedTemplate = _.template(json);
							exampleValues = parsedTemplate({list:response});
							document.getElementById('output_div').innerHTML=exampleValues;
							
							}
						});	

					},
				    error: function( jqXhr, textStatus, errorThrown ){
						console.log("error");
						document.getElementById('output_div').innerHTML='<div class="alert alert-danger"><strong>Error!</strong> Internal API Error.</div>';
					}
				});
    }

	
}