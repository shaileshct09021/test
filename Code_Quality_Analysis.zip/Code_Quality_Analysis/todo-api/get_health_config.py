from elasticsearch import Elasticsearch


def get_conf(username, jobname):
    elas = Elasticsearch(["http://10.71.71.18:9200"])
    result = elas.get("jobdetails",jobname,doc_type=username)
    config = result['_source']['configuration']
    return config

#c = get_conf('shweta-chogale', '1479724924_Zportall')
#print c
