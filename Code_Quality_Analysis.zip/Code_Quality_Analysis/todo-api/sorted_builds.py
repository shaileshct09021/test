from elasticsearch import Elasticsearch
import sys, collections
#the list of builds are returned for the particular job
def listsortedbuilds(jobname, start, till):
    
    builds_id =[] 
    builds =  []
    elastic = Elasticsearch(["http://10.71.71.18:9200"])
    res_count = elastic.count(index ="reportstore", doc_type=jobname)
    count = res_count['count']
    res = elastic.search("reportstore", doc_type=jobname, from_=0, size=count)
    
    for data in res['hits']['hits']:
        #builds.append(str(data['_id']))
        #if 'health' in data['_source']:
         #builds[str(data['_id'])] = data['_source']['health']
         builds_id.append(int(data['_id']))
    builds_id = sorted(builds_id)
    print builds_id
    builds = builds_id[start-1: till-1]
    print builds
    return builds

#listbuilds(sys.argv[1],3,10)

