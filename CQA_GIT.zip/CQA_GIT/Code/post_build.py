import os, time, sys
from elasticsearch import Elasticsearch
from jenkinsapi.jenkins import Jenkins
from jenkinsapi import jenkins
import pylintreport
import healthcheck
import email_sender, detailed, overview
#import xml.etree.ElementTree as ET


def get_build(jobname):
    J = Jenkins('http://10.71.71.18:8080', "admin", "admin123")
    job = J[jobname]
    lgb = job.get_build_ids()
    return lgb.next()

#file = sys.argv[1]
jobname = sys.argv[1]
#if '_pylint' in file:
    #file=file.replace("_pylint","",1)
#elif '_sonar' in file:
    #file=file.replace("_sonar","",1)

build_id = get_build(jobname)

#time.sleep(100)

serverurl = 'http://10.71.71.18:9000'
#tree = ET.parse(file)

#jobname = tree.find('./jobname').text

es = Elasticsearch(["http://10.71.71.18:9200"])
result = es.get("jobdetails", jobname)

details = result['_source']
#email_list = []
language = details['language'] #tree.find('./language').text

#print type(details['email'])
email_list = details['email']
#root = tree.getroot()
#for element in root.iter('email_list'):
#     for mail in element:
#         email_list.append(mail.text)

#email_list = ['waghprags@gmail.com' , 'pragati.wagh@gslab.com']
key = jobname +'_'+ details['branch'] #tree.find('./projectKey').text
print key
#get the timestamp of particular build
server = jenkins.Jenkins('http://10.71.71.18:8080', username='admin', password='admin123')

timestp = server[jobname]
time1 = (timestp.get_build(build_id).get_timestamp())

if language == 'python':
    while os.path.isfile('/var/lib/jenkins/workspace/' + jobname + '/pylint.json') == False:
        time.sleep(5)
    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')
    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')
    pylnt = pylintreport.generate_report(jobname)
    time.sleep(100)
    ov_rpt = overview.overview_analysis(jobname, serverurl, key)
    dt_rpt = detailed.detailed_analysis(jobname, serverurl, key)
    doc = {"overview" : {"sonar" : ov_rpt['overview'], "pylint" : pylnt['score']}, "detailed" : {"sonar" : dt_rpt, "pylint" : pylnt['detailed']}, "health" : ov_rpt['health'], "timestamp" : time1}
    #report = {}
    #report['sonar'] = json_string
    #doc['detailed'] = report
    es = Elasticsearch(["http://10.71.71.18:9200"])
    #print doc
    es.index(index="reportstore", doc_type=jobname, id=build_id, body=doc)
    
    time.sleep(100)
    #healthcheck.health(jobname, build_id)
    email_sender.mail_the_report(jobname, email_list)

else:
    #overview.overview_analysis(jobname, serverurl, key)
    #detailed.detailed_analysis(jobname, serverurl, key)
    ov_rpt = overview.overview_analysis(jobname, serverurl, key)
    dt_rpt = detailed.detailed_analysis(jobname, serverurl, key)
    doc = {"overview" : {"sonar" : ov_rpt['overview'] }, "detailed" : {"sonar" : dt_rpt }, "health" : ov_rpt['health'], "timestamp" : time1 }
    #report = {}
    #report['sonar'] = json_string
    #doc['detailed'] = report
    es = Elasticsearch(["http://10.71.71.18:9200"])
    #print doc
    es.index(index="reportstore", doc_type=jobname, id=build_id, body=doc)
    #healthcheck.health(jobname, build_id)

    time.sleep(100)

    email_sender.mail_the_report(jobname, email_list)



