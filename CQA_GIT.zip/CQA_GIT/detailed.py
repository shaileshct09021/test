import requests
import json
import csv


# return the result generated from API in json format
def getJasonresult(req_url):
    resp = requests.get(req_url)

    if resp.status_code != 200:
        # This means something went wrong.
        raise ApiError('GET /tasks/ {}'.format(resp.status_code))

    return resp.json()

#Writes json data to a file for further processing
def writeToFile(filename, data):
    string_data = json.dumps(data)
    with open(filename, "w") as f:
        f.write(string_data)

#Reads the result and displays to the user
def readAndStore(filename,json_data):

    json_file_handler = open(filename,"r")
    json_string = json_file_handler.read()
    loaded_json_string = json.loads(json_string)

    for element in loaded_json_string:
        if 'msr' in element:
            json_data = element.get('msr')
            
        elif 'issues' in element :
            json_data = loaded_json_string.get('issues')


    return json_data



def writeToCsv(json_string,csvwriter):
    neglect_parameters = {'transitions', 'frmt_val', 'project', 'flows', 'componentId', 'rule'}
    count = 0
    for string_instance in json_string:
           if type(json_string) == list:
                 header = string_instance.keys()
                 select_value = string_instance.values()
             
                 for parameter in neglect_parameters:
                    if parameter in header:
                     index = header.index(parameter)

                     select_value.remove(select_value[index])
                     header.remove(parameter)

                 if count == 0:
                    csvwriter.writerow(header)

                 count += 1
                 csvwriter.writerow(select_value)


           empty_line = ['', '']
           csvwriter.writerow(empty_line)


def detailed_analysis():

    url1 = 'http://10.71.71.18:9000/api/resources?resource=locusfile&metrics=complexity'
    data_initial = getJasonresult(url1)
    json_file_handler = "ca_j2.json"
    writeToFile(json_file_handler, data_initial)
    json_string=readAndStore(json_file_handler, json_data={})

    csv_file_handler = open('detailed.csv', 'w')
    csvwriter = csv.writer(csv_file_handler)
    writeToCsv(json_string, csvwriter)


    url1 = 'http://10.71.71.18:9000/api/duplications/show?key=locusfile'
    data_initial = getJasonresult(url1)
    json_file_handler = "ca_j2.json"
    writeToFile(json_file_handler, data_initial)
    json_string=readAndStore(json_file_handler, json_data={})

    csv_file_handler = open('detailed.csv', 'a')
    csvwriter = csv.writer(csv_file_handler)

    writeToCsv(json_string, csvwriter)


    url1 = 'http://10.71.71.18:9000/api/resources?resource=locusfile&metrics=security_rating'
    data_initial = getJasonresult(url1)
    json_file_handler = "ca_j2.json"
    writeToFile(json_file_handler, data_initial)
    json_string=readAndStore(json_file_handler, json_data={})

    csv_file_handler = open('/home/pragati/project/2/detailed.csv', 'a')
    csvwriter = csv.writer(csv_file_handler)

    writeToCsv(json_string, csvwriter)


    url1 = 'http://10.71.71.18:9000/api/resources?resource=locusfile&metrics=class_complexity'
    data_initial = getJasonresult(url1)
    json_file_handler = "ca_j2.json"
    writeToFile(json_file_handler, data_initial)
    json_string = readAndStore(json_file_handler, json_data={})

    csv_file_handler = open('detailed.csv', 'a')
    csvwriter = csv.writer(csv_file_handler)

    writeToCsv(json_string, csvwriter)




    url4 = 'http://10.71.71.18:9000/api/issues/search?key=locusfile&additionalFields=transitions'
    data_initial = getJasonresult(url4)
    json_file_handler = "ca_j4.json"
    writeToFile(json_file_handler, data_initial)
    json_string = readAndStore(json_file_handler, json_data={})
    csv_file_handler = open('detailed.csv', 'a')
    csvwriter = csv.writer(csv_file_handler)
    heading = ['List of issues']
    csvwriter.writerow(heading)
    writeToCsv(json_string , csvwriter)
    csv_file_handler.close()
