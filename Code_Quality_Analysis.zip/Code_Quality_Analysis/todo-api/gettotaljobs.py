from elasticsearch import Elasticsearch

# the count of jobs belonging to particular user are returned.
def getcount(username):
   es = Elasticsearch(["http://10.71.71.18:9200"])
   res = es.search(index="jobdetails", doc_type=username)
   # for doc in res['hits']:
   #         (doc['total']).decode('utf-8')
   total = res['hits']['total']
   return total
