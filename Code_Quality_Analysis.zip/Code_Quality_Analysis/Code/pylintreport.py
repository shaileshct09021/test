import json
import csv

def generate_report(jobname, statement):
    filepath = '/var/lib/jenkins/workspace/'+jobname+'/pylint.json'
    file_handle = open(filepath,'r')
    json_file = file_handle.read()
    json_string = json.loads(json_file)
    csv_file_handler = open('/home/shweta/PycharmProjects/detailed_'+jobname+'.csv', 'a')
    csvwriter = csv.writer(csv_file_handler)
    writehead1 = ["Report by the pylint "]
    csvwriter.writerow(writehead1)
    count = 0
    for issue in json_string:

        header = issue.keys()
        values = issue.values()

        if count == 0:
           csvwriter.writerow(header)
           count +=1

        csvwriter.writerow(values)

    filepath = '/var/lib/jenkins/workspace/'+jobname+'/pylint1.txt'
    file_handle = open(filepath,'r')
    text_list = file_handle.readlines()
    csv_file_handler = open('/home/shweta/PycharmProjects/overview_'+jobname+'.csv', 'a')
    csvwriter = csv.writer(csv_file_handler)
    
    writehead = ["The rating by pylint"]
    csvwriter.writerow(writehead)
    convention = []
    count = 0
    error = []
    warning = []
    refactor = []    
    writeline = [ text_list [-2] ]
    csvwriter.writerow(writeline)
    csv_file_handler.close()
    for data in json_string:
       count +=1
       if data["type"] == "convention":
          convention.append(data)
       if data["type"] == "error":
          error.append(data)
       if data["type"] == "warning":
          warning.append(data)
       if data["type"] == "refactor":
          refactor.append(data)
    data1 = {"convention" : convention, "error" : error, "warning" : warning, "refactor":refactor}
    pylint = {}
    #statement_data = overview.get_loc(projectkey)
    #statement = int(statement_data['ncloc'])
    score = (float((5*count)/statement)*10)
    pylint['score'] = score
    pylint['detailed'] = data1
    return pylint




