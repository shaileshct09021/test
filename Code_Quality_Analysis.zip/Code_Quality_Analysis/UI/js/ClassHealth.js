
function ClassHealth(){ 
	var classmetrices,und,dulpicate,couple_obj,cy_comp,code_ratio,d_tree,eloc,lack_cohesion,loc,no_method;
	var bugs,code_smell,issues,Vulnera,nlb;
	
	this.setHealthConfig = function(classmetrices,und,dulpicate)
	{
		this.classmetrices=classmetrices;
		this.und=und;
		this.dulpicate=dulpicate;
	}
	this.setHealthClassConfig = function(couple_obj,cy_comp,code_ratio,d_tree,eloc,lack_cohesion,loc,no_method)
	{
		this.couple_obj=couple_obj;
		this.cy_comp=cy_comp;
		this.code_ratio=code_ratio;
		this.d_tree=d_tree;
		this.eloc=eloc;
		this.lack_cohesion=lack_cohesion;
		this.loc=loc;
		this.no_method=no_method;
	}
	this.setHealthSonarConfig = function(bugs,code_smell,issues,Vulnera)
	{
		this.bugs=bugs;
		this.code_smell=code_smell;
		this.issues=issues;
		this.Vulnera=Vulnera;
	}
	this.setHealthSimianConfig = function(nlb)
	{
		this.nlb=nlb;
	}
	this.calcHealthClass = function(couple_obj,cy_comp,code_ratio,d_tree,eloc,lack_cohesion,loc,no_method){
		var divBy = 8;
		
		divBy = divBy - (this.couple_obj>0?0:1);
		var new_couple_obj=(couple_obj/loc)*(this.couple_obj);
		
		divBy = divBy - (this.cy_comp>0?0:1);
		if(cy_comp<=10)
		{
			cy_comp_parm = 10;
		}
		else if(cy_comp<=20 || cy_comp>10)
		{
			cy_comp_parm = 5;
		}
		else if(cy_comp<50 || cy_comp>20)
		{
			cy_comp_parm = 2.5;
		}
		else if(cy_comp>=50)
		{
			cy_comp_parm = 0;
		}
		var new_cy_comp=(cy_comp/10)*this.cy_comp;
		
		divBy = divBy - (this.code_ratio>0?0:1);
		var new_code_ratio=code_ratio*this.code_ratio;
		
		divBy = divBy - (this.d_tree>0?0:1);
		if(d_tree>0 && d_tree<4)
		{
			d_tree_parm = 10;
		}
		else if(d_tree<0 || d_tree>4)
		{
			d_tree_parm = 0;
		}
		else if(d_tree==0 || d_tree==4)
		{
			d_tree_parm = 5;
		}
		var new_d_tree=(d_tree_parm/10)*this.d_tree;
		
		divBy = divBy - (this.eloc>0?0:1);
		var new_eloc=(eloc/loc)*this.eloc;
		
		divBy = divBy - (this.lack_cohesion>0?0:1);
		
		if(lack_cohesion>1 && lack_cohesion<4)
		{
			lack_cohesion_parm = 10;
		}
		else if(lack_cohesion<1 || lack_cohesion>4)
		{
			lack_cohesion_parm = 0;
		}
		else if(lack_cohesion==1 || lack_cohesion==4)
		{
			lack_cohesion_parm = 5;
		}
		var new_lack_cohesion=(lack_cohesion_parm/10)*this.lack_cohesion;
		
		divBy = divBy - (this.loc>0?0:1);
		var new_loc=(loc/loc)*this.loc;;
		
		divBy = divBy - (this.no_method>0?0:1);
		
		if(no_method>3 && no_method<7)
		{
			no_method_parm = 10;
		}
		else if(no_method<3 || no_method>7)
		{
			no_method_parm = 0;
		}
		else if(no_method==3 || no_method==7)
		{
			no_method_parm = 5;
		}
		
		var new_no_method=(no_method_parm/10)*this.no_method;
		
		
		console.log(new_couple_obj,this.couple_obj,this.loc,loc,couple_obj);
		console.log(new_cy_comp);
		console.log(new_code_ratio);
		console.log(new_d_tree);
		console.log(new_eloc);
		console.log(new_lack_cohesion);
		console.log(new_loc);
		console.log(new_no_method);
		//console.log(divBy);
		return(eval(new_couple_obj+new_cy_comp+new_code_ratio+new_d_tree+new_eloc+new_lack_cohesion+new_loc+new_no_method)/divBy);
		
	}
	this.calcHealthSonar = function(bugs,code_smell,issues,Vulnera,loc){
		var divBy = 400;
		console.log(code_smell);
		
		divBy = divBy - (this.bugs>0?0:100);
		if(bugs==0 || bugs=='0')
		{
		var new_bugs=parseInt(this.bugs);
		}
		else
		{
		var new_bugs=parseInt((bugs/loc)*this.bugs);	
		}
		
		
		divBy = divBy - (this.code_smell>0?0:100);
		
		if(code_smell==0 || code_smell=='0')
		{
		var new_code_smell=parseInt(this.code_smell);
		}
		else
		{
		var new_code_smell=parseInt(((code_smell/loc)*100)*(this.code_smell/100));
		console.log(code_smell,loc,this.code_smell);	
		}
		
		divBy = divBy - (this.issues>0?0:100);
		if(issues==0 || issues=='0')
		{
		var new_issues=parseInt(this.issues);
		}
		else
		{
		var new_issues=parseInt((issues/loc)*this.issues);
		}
		
		divBy = divBy - (this.Vulnera>0?0:100);
		if(Vulnera==0 || Vulnera=='0')
		{
		var new_Vulnera=parseInt(this.Vulnera);
		}
		else
		{
		var new_Vulnera=parseInt((Vulnera/loc)*this.Vulnera);
		}
		console.log(new_bugs+new_code_smell+new_issues+new_Vulnera);
		
		return(eval(new_bugs+new_code_smell+new_issues+new_Vulnera)*10/divBy);
	}
	this.getLOCCodeSmell = function(codesmell){
		var sum=0;
		for(x of codesmell)
		{
			//console.log(x.textRange.endLine);
			end = x.textRange.endLine;
			start = x.textRange.startLine;
			sum= sum+eval(eval(end+1)-start);
		}
		return sum;
		
	}
	this.getLOCbugs = function(bugs){
		var sum=0;
		for(x of bugs)
		{
			//console.log(x.textRange.endLine);
			end = x.textRange.endLine;
			start = x.textRange.startLine;
			sum= sum+eval(eval(end+1)-start);
		}
		return sum;
		
	}
	this.getLOCVulneral = function(Vulneral){
		var sum=0;
		for(x of Vulneral)
		{
			//console.log(x.textRange.endLine);
			end = x.textRange.endLine;
			start = x.textRange.startLine;
			sum= sum+eval(eval(end+1)-start);
		}
		return sum;
		
	}
	this.getLOCissues = function(issues){
		var sum=0;
		for(x of issues)
		{
			//console.log(x.textRange.endLine);
			end = x.textRange.endLine;
			start = x.textRange.startLine;
			sum= sum+eval(eval(end+1)-start);
		}
		return sum;
		
	}
	this.calcHealthSimian = function(){
		
	}
} 
