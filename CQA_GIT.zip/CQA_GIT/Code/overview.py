import requests
import json
import csv
from jenkinsapi import jenkins

# return the result generated from API in json format
def getJasonresult(req_url):
    #while requests.get('http://10.71.71.18:9000/api/projects/index/?key='+projectkey is
    resp = requests.get(req_url)
    #if resp.status_code != 200:
        # This means something went wrong.
        #raise ApiError('GET /tasks/ {}'.format(resp.status_code))

    return resp.json()

#Writes json data to a file for further processing
def writeToFile(filename, data):
    string_data=json.dumps(data)
    with open(filename, "w") as f:
        f.write(string_data)

#Reads the result and displays to the user
def readAndStore(filename, json_data):

    json_file_handler = open(filename, "r")
    json_string = json_file_handler.read()
    loaded_json_string = json.loads(json_string)

    for element in loaded_json_string:
        if('msr' in element):
            json_data = element.get('msr')

    return json_data


def overview_analysis(jobname, serverurl, projectkey):

    # overview report for a sonar tool using an available sonar API   
    print projectkey
    url_req_overview = 'http://10.71.71.18:9000/api/resources?resource='+projectkey+'&metrics=ncloc,code_smells,comment_lines,commented_out_code_lines,classes,files,vulnerabilities,functions,comment_lines_density,duplications_data,class_complexity,complexity,file_complexity'
    
    data_initial = getJasonresult(url_req_overview)

    json_file_handler = "/home/shweta/PycharmProjects/ca_j1.json"
    writeToFile(json_file_handler, data_initial)
    json_string = readAndStore(json_file_handler, json_data={})

    json_string_parsed = json_string
    # Writing to the analysis csv file

    csv_file_handler = open('/home/shweta/PycharmProjects/overview_'+jobname+'.csv', 'a')
    csvwriter = csv.writer(csv_file_handler)
    parameters ={'ncloc' : 'Lines of code', 'code_smells' : 'Number of code smells', 'comment_lines' : 'Comment lines', 'commented_out_code_lines' : 'Commented lines of code', 'classes' : 'Number of classes', 'vulnerabilities' : 'Number of vulnerabilities', 'class_complexity' : 'Average complexity by class', 'functions' : 'Number of functions', 'comment_lines_density' : 'Density of commented lines', 'duplications_data' : 'Duplication of data', 'complexity' : 'Code Complexity', 'file_complexity' : 'Average complexity by file'}
    count = 0
    row = []
    for string_instance in json_string:

      if count == 0:

             header1 = string_instance.keys()
             header1.remove('frmt_val')
             #print header
             header = ['Description of Key'] + header1
             csvwriter.writerow(header)

             count += 1
      select_value = string_instance.values()
      select_value.remove(select_value[0])
      for parameter in parameters:
            del row[:]
            if string_instance['key'] == parameter:
                row = [parameters[parameter]]+select_value
                # print row
                #print select_value
                csvwriter.writerow(row)

    
    csv_file_handler.close()
    code_smell = ncloc = code_complexity = 0.0
    for msr in json_string:
        if msr['key'] == 'code_smells':
            code_smell = float(msr['val'])
        if msr['key'] == 'ncloc':
            ncloc = float(msr['val'])
        if msr['key'] == 'complexity':
            code_complexity = float(msr['val'])



    code_smell_percentage = float(code_smell/ncloc) * 100
    #print code_smell_percentage

    code_complexity_percentage = float(code_complexity/ncloc) * 100

    summation = code_smell_percentage + ((3/4) * code_complexity_percentage)
    average = summation /2

    #print average

    #timestamp of build
    #server = jenkins.Jenkins('http://10.71.71.18:8080', username='admin', password='admin123')
    #timestp = server[jobname]
    #time1 = (timestp.get_build(build_id).get_timestamp())
    overview = {}


    if average <= 10:
        #elas.update(index="reportstore", id=build_id, doc_type=jobname, body={"doc" : {"health" : 1 , "timestamp" : time1}})
        health = 1
        overview['health'] = 1
    if average > 10 and average <= 30 :
        #elas.update(index="reportstore", id=build_id, doc_type=jobname, body={"doc": {"health": 2, "timestamp" : time1}})
        health = 2
        overview['health'] = 2
    if average > 30 and average <= 50 :
        #elas.update(index="reportstore", id=build_id, doc_type=jobname, body={"doc": {"health": 3, "timestamp" : time1}})
        health = 3
        overview['health'] = 3
    if average > 50:
        #elas.update(index="reportstore", id=build_id, doc_type=jobname, body={"doc": {"health": 4, "timestamp" : time1}})
        health = 4
        overview['health'] = 4

    overview['overview'] = json_string
    #overview['health'] = { "health" : health , "timestamp" : time1 }
    return overview

