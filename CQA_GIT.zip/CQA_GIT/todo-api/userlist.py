import xml.etree.ElementTree as ET

def userexist(username):
    exist = False
    tree = ET.parse('/var/lib/jenkins/credentials.xml')
    users = tree.findall('.//username')
    for user in users:
        print user.text
        if username == user.text:
            exist = True
            print user.text
    return exist
