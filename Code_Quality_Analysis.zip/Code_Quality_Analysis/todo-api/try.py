from elasticsearch import Elasticsearch
import sys
jobname='1474623795_Valid'
build_id = 9

def get(jobname, build_id):
    elas = Elasticsearch(["http://10.71.71.18:9200"])
    res = elas.search("reportstore", doc_type=jobname)
    for data in res['hits']['hits']:
        if str(data['_id']) == build_id:
            data = data['_source']
    print data
    # return data
get(jobname, build_id)
