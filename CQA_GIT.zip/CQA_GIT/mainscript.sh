python /home/shweta/PycharmProjects/Code/Main.py $1 $2
