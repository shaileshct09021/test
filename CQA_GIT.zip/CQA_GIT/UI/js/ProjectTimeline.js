
               function InitChart() {//start init
                    
                   /*  var data = [{
                        "project": "ABC",
                        "health": "202",
                        "time": "2000"
                    }, {
                        "project": "ABC",
                        "health": "215",
                        "time": "2002"
                    }, {
                        "project": "ABC",
                        "health": "179",
                        "time": "2004"
                    }, {
                        "project": "ABC",
                        "health": "199",
                        "time": "2006"
                    }, {
                        "project": "ABC",
                        "health": "134",
                        "time": "2008"
                    }, {
                        "project": "ABC",
                        "health": "176",
                        "time": "2010"
                    }, {
                        "project": "XYZ",
                        "health": "100",
                        "time": "2000"
                    }, {
                        "project": "XYZ",
                        "health": "215",
                        "time": "2002"
                    }, {
                        "project": "XYZ",
                        "health": "179",
                        "time": "2004"
                    }, {
                        "project": "XYZ",
                        "health": "199",
                        "time": "2006"
                    }, {
                        "project": "XYZ",
                        "health": "134",
                        "time": "2008"
                    }, {
                        "project": "XYZ",
                        "health": "176",
                        "time": "2013"
                    }, {
                        "project": "PQR",
                        "health": "200",
                        "time": "2000"
                    }, {
                        "project": "PQR",
                        "health": "215",
                        "time": "2002"
                    }, {
                        "project": "PQR",
                        "health": "179",
                        "time": "2004"
                    }, {
                        "project": "PQR",
                        "health": "199",
                        "time": "2006"
                    }, {
                        "project": "PQR",
                        "health": "134",
                        "time": "2008"
                    }, {
                        "project": "PQR",
                        "health": "176",
                        "time": "2010"
                    }];
                    var dataGroup = d3.nest()
                        .key(function(d) {return d.project;})
                        .entries(data);
                    console.log(JSON.stringify(dataGroup));
                    var color = d3.scale.category10();
                    var vis = d3.select("#visualisation"),
                        WIDTH = 900,
                        HEIGHT = 500,
                        MARGINS = {
                            top: 50,
                            right: 20,
                            bottom: 50,
                            left: 50
                        },
                        lSpace = WIDTH/dataGroup.length;
                        xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([d3.min(data, function(d) {
                            return d.time;
                        }), d3.max(data, function(d) {
                            return d.time;
                        })]),
                        yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([d3.min(data, function(d) {
                            return d.health;
                        }), d3.max(data, function(d) {
                            return d.health;
                        })]),
                        xAxis = d3.svg.axis()
                        .scale(xScale),
                        yAxis = d3.svg.axis()
                        .scale(yScale)
                        .orient("left");
                    
                    vis.append("svg:g")
                        .attr("class", "x axis")
                        .attr("transform", "translate(0," + (HEIGHT - MARGINS.bottom) + ")")
                        .call(xAxis);
                    vis.append("svg:g")
                        .attr("class", "y axis")
                        .attr("transform", "translate(" + (MARGINS.left) + ",0)")
                        .call(yAxis);
                        
                    var lineGen = d3.svg.line()
                        .x(function(d) {
                            return xScale(d.time);
                        })
                        .y(function(d) {
                            return yScale(d.health);
                        })
                        .interpolate("basis");
						
                    dataGroup.forEach(function(d,i) {
                        vis.append('svg:path')
                        .attr('d', lineGen(d.values))
                        .attr('stroke', function(d,j) { 
                                return "hsl(" + Math.random() * 360 + ",100%,50%)";
                        })
                        .attr('stroke-width', 2)
                        .attr('id', 'line_'+d.key)
                        .attr('fill', 'none');
						
                        vis.append("text")
                            .attr("x", (lSpace/2)+i*lSpace)
                            .attr("y", HEIGHT)
                            .style("fill", "black")
                            .attr("class","legend")
                            .on('click',function(){
                                var active   = d.active ? false : true;
                                var opacity = active ? 0 : 1;
                                d3.select("#line_" + d.key).style("opacity", opacity);
                                d.active = active;
                            })
                            .text(d.key);
                    });
                    
                }
                */
    d3.json('http://10.71.71.18/Code_Quality_Analysis/json.json', function (error, myData) {
    // Renders a line chart

		nv.addGraph(function() {
        var chart = nv.models.lineChart();
        chart.brushExtent([50,70]);
        chart.xAxis.tickFormat(d3.format(',f')).axisLabel("Time");
		chart.yAxis.tickFormat(d3.format(',f')).axisLabel("Health");
        chart.x2Axis.tickFormat(d3.format(',f'));
        //chart.yTickFormat(d3.format(',.2f'));
        chart.useInteractiveGuideline(true);
		console.log(myData);
        d3.select('#chart svg')
            .datum(myData)
            .call(chart);
        nv.utils.windowResize(chart.update);
        return chart;
    });
	

	});
	
    function testData() {
        return stream_layers(10,128,.1).map(function(data, i) {
            return {
                key: 'Stream' + i,
                area: i === 1,
                values: data
            };
        });
    }
          
}//end init