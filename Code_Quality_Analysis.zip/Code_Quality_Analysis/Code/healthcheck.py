import sys
sys.path.append("/usr/local/lib/python2.7/dist-packages/")
from elasticsearch import Elasticsearch
from jenkinsapi import jenkins

def health(jobname, build_id):
    server = jenkins.Jenkins('http://10.71.71.18:8080', username='admin', password='admin123')
    elas = Elasticsearch(["http://10.71.71.18:9200"])
    code_smell = ncloc = code_complexity = 0.0
    result = elas.get(index="reportstore", id=build_id, doc_type=jobname)
    sonar_result = result['_source']['overview']['sonar']
    for msr in sonar_result:
        if msr['key'] == 'code_smells':
            code_smell = float(msr['val'])
        if msr['key'] == 'ncloc':
            ncloc = float(msr['val'])
        if msr['key'] == 'code_complexity':
            code_complexity = float(msr['val'])

    code_smell_percentage = float(code_smell/ncloc) * 100
    #print code_smell_percentage

    code_complexity_percentage = float(code_complexity/ncloc) * 100

    summation = code_smell_percentage + ((3/4) * code_complexity_percentage)
    average = summation /2

    #print average

    #timestamp of build
    timestp = server[jobname]
    time1 = (timestp.get_build(build_id).get_timestamp())



    if average <= 10:
        elas.update(index="reportstore", id=build_id, doc_type=jobname, body={"doc" : {"health" : 1 , "timestamp" : time1}})


    if average > 10 and average <= 30 :
        elas.update(index="reportstore", id=build_id, doc_type=jobname, body={"doc": {"health": 2, "timestamp" : time1}})

    if average > 30 and average <= 50 :
        elas.update(index="reportstore", id=build_id, doc_type=jobname, body={"doc": {"health": 3, "timestamp" : time1}})

    if average > 50:
        elas.update(index="reportstore", id=build_id, doc_type=jobname, body={"doc": {"health": 4, "timestamp" : time1}})
