#!/usr/bin/env python
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from smtplib import SMTP
import smtplib
import sys


def mail_the_report():
    recipients = ['waghprags@gmail.com']
    emaillist = [elem.strip().split(',') for elem in recipients]
    msg = MIMEMultipart()
    msg['Subject'] = "testing application"
    msg['From'] = 'pragati.wagh@gslab.com'
    msg['Reply-to'] = 'pragati.wagh@gslab.com'

    msg.preamble = 'Multipart message.\n'

    part = MIMEText("Hi,\n please find the attached file containing the overview and detailed report")
    msg.attach(part)

    part = MIMEApplication(open('detailed.csv', 'rb').read())
    part.add_header('Content-Disposition', 'attachment', filename='detailed.csv')
    msg.attach(part)

    part = MIMEApplication(open('overview.csv', 'rb').read())
    part.add_header('Content-Disposition', 'attachment', filename='overview.csv')
    msg.attach(part)


    server = smtplib.SMTP("smtp.gmail.com:587")
    server.ehlo()
    server.starttls()
    server.login("pragati.wagh@gslab.com", "gslab_account")

    server.sendmail(msg['From'], emaillist, msg.as_string())
