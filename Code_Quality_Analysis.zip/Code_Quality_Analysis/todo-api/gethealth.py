
from elasticsearch import Elasticsearch


# the health of a particula
def returnhealth(username):
    es = Elasticsearch(["http://10.71.71.18:9200"])
    
    jobs =[]
    
    res = es.search(index="jobdetails", doc_type="Pragati",size=20)
    for doc in res['hits']['hits']:
        jobs.append( (doc['_id']).decode('utf-8'))
    response = {}
    count =0
    for job in jobs:
        print job
        build_data = {}
        data = es.search(index='reportstore',doc_type=job,filter_path=['hits.hits._source.health','hits.hits._id','hits.hits._type'],size=20)
        # print data
        if data != {}:
            for unit in data['hits']['hits']:
                 print unit
                 if '_source' in unit.keys():
                    health = unit['_source']['health']
                    id = unit['_id']
                    build_data[id] = health
            response[job ]= build_data
        print  data#id , health

    return response

