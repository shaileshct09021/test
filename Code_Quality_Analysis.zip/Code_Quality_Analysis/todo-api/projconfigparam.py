import ConfigParser

def getprojconfig(jobname):
	config = ConfigParser.RawConfigParser()
	config.read('/var/lib/jenkins/workspace'+jobname+'/exampleconfigfile.cfg')
	loc = config.getint('Class_metrices','loc')
	cbo = config.getint('Class_metrices','cbo')
	nom = config.getint('Class_metrices','nom')
	eloc = config.getint('Class_metrices','eloc')
	cc = config.getint('Class_metrices','cc')
	dit = config.getint('Class_metrices','dit')
	lac = config.getint('Class_metrices','lac')
	ccr = config.getint('Class_metrices','ccr')
	doc = {'loc':loc,'cbo':cbo,'nom':nom,'eloc':eloc,'cc':cc,'dit':dit,'lac':lac,'ccr':ccr}
	return doc

