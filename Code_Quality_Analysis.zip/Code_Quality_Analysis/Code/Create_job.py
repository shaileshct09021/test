import os
from jenkinsapi import jenkins


import jenkins as j

def create_job(server, jobname, language):
    #simple job creation with empty configurations initially
        if language == 'python':
            server.create_job(jobname, j.EMPTY_CONFIG_XML)
            directory = '/var/lib/jenkins/workspace/'+jobname
    
    
            if not os.path.exists(directory):
               os.makedirs(directory)     

            while os.access('/var/lib/jenkins/workspace/'+jobname,os.W_OK) == 'False':
                 os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')

            #server.create_job(jobname+'_sonar', j.EMPTY_CONFIG_XML)
            #server.build_job(jobname+'_sonar', None)
            os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')
        else:
            server.create_job(jobname, j.EMPTY_CONFIG_XML)
            #server.build_job(jobname, None)
            os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')



