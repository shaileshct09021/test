#!flask/bin/python

from flask import Flask, jsonify, abort, request, make_response, url_for
import sys, os, json
#sys.path.append('/usr/local/lib/python2.7/dist-packages')
sys.path.insert(0,'/etc/python')
sys.path.insert(0,'/etc/python2.7')
sys.path.append('/usr/local/lib/python2.7/dist-packages')
#import writexml
#import writeelastic
#import listfiles
#import jobinformation
#import listofbuilds
#import getreport
#import lxml.builder

app_post = Flask(__name__)

def add_cors_header(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Authorization, Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'POST, GET, PUT, PATCH, DELETE, OPTIONS'
    return response

app_post.after_request(add_cors_header)

@app_post.route('/todo/posttasks', methods = ['GET'])
def hello():
    argument = request.args.get('jobname')
    command = 'sudo /home/shweta/PycharmProjects/postshell.sh ' + argument
    print argument
    os.system(command)
    return "Success",201 


if __name__ == '__main__':
    app_post.run(debug=True, host='127.0.0.1', port=5001, threaded=True)

