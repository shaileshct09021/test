import os


os.system('sudo rm -rf /var/lib/jenkins/workspace/try/myproj')
