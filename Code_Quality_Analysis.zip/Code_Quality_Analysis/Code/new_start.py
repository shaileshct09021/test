import sys
import elast
import json
sys.path.append('/home/shweta/PycharmProjects/Code/')
#import understand_data
sys.path.append("/home/shweta/scitools/bin/linux64/python/")
import understand

print ("TASK Mapping Class to Code Smell")
jobname = sys.argv[1]
#jobname = "1475484377_Zportal"


db = understand.open("/var/lib/jenkins/workspace/"+jobname+"/newDB.udb")
#db = understand.open("/var/lib/jenkins/workspace/1475484377_Zportal/newDB.udb")
filesname = []
for file in db.ents("File"):
    filesname.append(file.name())
#print (filesname)     
data = []
data_dict = {}
build_id = 41
#with open('/var/lib/jenkins/workspace/1475484377_Zportal/detailed.json','r') as file: 
with open('/var/lib/jenkins/workspace/'+jobname+'/detailed.json') as file:
    detail_file = json.loads(file.read()) # elast.all(jobname,build_id)

codesmell = detail_file['code_smells']
bugs = detail_file['bugs']
vulnerabilities = detail_file['vulnerabilities'][0]
#print (type(codesmell))
print ("Initialize....")
cc = 0
classlist = []
for classp in db.ents("class "):
     classlist.append(classp)
#print (classlist)

for classp in classlist:
    cc += 1
    count = classp.metric(("CountLine",))
    #if cc > 20:
    #   break

    if count["CountLine"] is not None:
        dataclass = []
        datacodesmell = []
        databugs = []
        datavulner = []
        for codefile in codesmell:
            #print (codefile)
            codefile1 = codefile["component"].split("/")
            codefile1 = codefile1[len(codefile1)-1]

            codefile2 = codefile1.split(".")
            codefile2 = codefile2[0]

            cname = classp.name().split(".")
            cname1 = cname[len(cname)-1]
            cname = cname1
            if cname ==  codefile2:
                #print (cname, codefile2)
                if codefile1 in filesname:
                    file = db.lookup(codefile1)[0]
                    for lexeme in file.lexer():
                        if lexeme.text()=="class":
                            obj =lexeme.next().next()
                            if obj.text() == cname:
                                print (cname)
                                sline = lexeme.line_begin()  
                                eline = int(count["CountLine"])+sline
                                try:
                                    if sline < codefile["textRange"]["startLine"] and codefile["textRange"]["startLine"]< eline and codefile["textRange"]["endLine"] < eline:
                                        #print (codefile["textRange"]["endLine"])
                                        #print (codefile["textRange"]["startLine"])
                                        datacodesmell.append(codefile)
                                        #print( dataclass)
                                        #break
                                except:
                                    msg = "Code Smell not found."
                                break
        dataclass.append(datacodesmell)
        print("Codesmell Loaded")

        for codefile in bugs:
            #print (codefile)
            codefile1 = codefile["component"].split("/")
            codefile1 = codefile1[len(codefile1)-1]

            codefile2 = codefile1.split(".")
            codefile2 = codefile2[0]

            cname = classp.name().split(".")
            cname1 = cname[len(cname)-1]
            cname = cname1
            if cname ==  codefile2:
                #print (cname, codefile2)
                if codefile1 in filesname:
                    file = db.lookup(codefile1)[0]
                    for lexeme in file.lexer():
                        if lexeme.text()=="class":
                            obj =lexeme.next().next()
                            if obj.text() == cname:
                                #print (cname)
                                sline = lexeme.line_begin()
                                eline = int(count["CountLine"])+sline
                                try:
                                    if sline < codefile["textRange"]["startLine"] and codefile["textRange"]["startLine"]< eline and codefile["textRange"]["endLine"] < eline:
                                        #print (codefile["textRange"]["endLine"])
                                        #print (codefile["textRange"]["startLine"])
                                        databugs.append(codefile)
                                        #print( dataclass)
                                        #break
                                except:
                                    msg = "Code Smell not found."
                                break
        dataclass.append(databugs)

        for codefile in vulnerabilities:
            #print (codefile)
            codefile1 = codefile["component"].split("/")
            codefile1 = codefile1[len(codefile1)-1]

            codefile2 = codefile1.split(".")
            codefile2 = codefile2[0]

            cname = classp.name().split(".")
            cname1 = cname[len(cname)-1]
            cname = cname1
            if cname ==  codefile2:
                #print (cname, codefile2)
                if codefile1 in filesname:
                    file = db.lookup(codefile1)[0]
                    for lexeme in file.lexer():
                        if lexeme.text()=="class":
                            obj =lexeme.next().next()
                            if obj.text() == cname:
                                #print (cname)
                                sline = lexeme.line_begin()
                                eline = int(count["CountLine"])+sline
                                try:
                                    if sline < codefile["textRange"]["startLine"] and codefile["textRange"]["startLine"]< eline and codefile["textRange"]["endLine"] < eline:
                                        #print (codefile["textRange"]["endLine"])
                                        #print (codefile["textRange"]["startLine"])
                                        datavulner.append(codefile)
                                        #print( dataclass)
                                        #break
                                except:
                                    msg = "Code Smell not found."
                                break
        dataclass.append(datavulner)

        data_dict[cname] = dataclass
        
        if len(dataclass) > 0:
           data.append(data_dict)      
           #del (data_dict)

#understand_data.understand_metrics(jobname)
json.dump(data_dict,open('/var/lib/jenkins/workspace/'+jobname+'/mapping.json','w'))
print("Exit from New Strart")
