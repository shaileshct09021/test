function ClassBuild(pname,build_id)
{
	var pname = pname;
	var build_id = build_id;

	this.runBuild = function(){

		console.log('Class'+pname);
		$('#pleaseWaitDialog').modal('show');
		
		var formData = JSON.stringify({jobname : pname});
		
		$.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/buildproject',
					    dataType: 'json',
					    type: 'post',
					    contentType: 'application/json',
					    data: formData,
						success: function(json) {
							console.log(json['status']);
							document.getElementById('output_div').innerHTML='<div class="alert alert-success"><strong>Success!</strong> Project build will be Added Shortly.</div>';
							$('#pleaseWaitDialog').modal('hide');
							}
					});
	}

	this.DreportBuild = function(){
		
		
		var formData = JSON.stringify({jobname : pname,build_id : build_id});
		
		var tempValues="";
		var dataTemplate="";
		
		$.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/getreport',
					    dataType: 'json',
					    type: 'post',
					    contentType: 'application/json',
					    data: formData,
						success: function(result) {
							
							console.log('Class');
							$.ajax({
									url:'/Code_Quality_Analysis/view_detail.html',
									type:'GET',
									async: true,
									success: function(json) {

										dataTemplate = _.template(json);
										tempValues = dataTemplate({build_detail:result});
										document.getElementById("output_div").innerHTML=tempValues;
										
										}
									});

							}
					});
	}
	this.OreportBuild = function(){
		
		
		var formData = JSON.stringify({jobname : pname,build_id : build_id});
		
		var tempValues="";
		var dataTemplate="";
		
		$.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/getreport',
					    dataType: 'json',
					    type: 'post',
					    contentType: 'application/json',
					    data: formData,
						success: function(result) {
							
							console.log('Class');
							$.ajax({
									url:'/Code_Quality_Analysis/view_overview.html',
									type:'GET',
									async: true,
									success: function(json) {

										dataTemplate = _.template(json);
										tempValues = dataTemplate({build_detail:result});
										document.getElementById("output_div").innerHTML=tempValues;
										
										}
									});

							}
					});
	}

}