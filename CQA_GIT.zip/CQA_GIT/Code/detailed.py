import requests
import json
import csv
from elasticsearch import Elasticsearch

# return the result generated from API in json format
def getJasonresult(req_url):
    resp = requests.get(req_url)
    return resp.json()

#Writes json data to a file for further processing
def writeToFile(filename, data):
    string_data=json.dumps(data)
    with open(filename, "w") as f:
        f.write(string_data)

#Reads the result from file and selects the required part return it
def readAndStore(filename, json_data):

    json_file_handler = open(filename, "r")
    json_string = json_file_handler.read()
    loaded_json_string = json.loads(json_string)

    for element in loaded_json_string:
        if('msr' in element):
            json_data = element.get('msr')
            #print type(json_data) , "is type at msr "
        elif('issues' in element):
            json_data = loaded_json_string.get('issues')


    return json_data



def writeToCsv(json_string, csvwriter):
    list = [] 
    heading =["The CODE_SMELLS with in the project"]
    csvwriter.writerow(heading)
    
    tags= ['status','severity','author','message','line','component','rule','debt','effort','key','creationDate','updateDate']
    csvwriter.writerow(tags)
    for str_inst in json_string:
         if str_inst[u'type'] == 'CODE_SMELL':
             del list[:]
             for tag in tags:
                if tag not in str_inst:
                    list = list + ['--']
                else:    
                    list = list + [str_inst[tag]]
         csvwriter.writerow(list)
   

    heading = ["The VULNERABILTY with in the project"]
    csvwriter.writerow(heading)
    csvwriter.writerow(tags)  
   
    for str_inst in json_string:
         if str_inst[u'type'] == 'VULNERABILITY':
             del list[:]
             for tag in tags:
                list = list + [str_inst[tag]]
         csvwriter.writerow(list)
   
    heading = ["The BUGS with in the project"]
    csvwriter.writerow(heading)
    csvwriter.writerow(tags) 
   
    for str_inst in json_string:
         if str_inst[u'type'] == 'BUG':
             del list[:]
             for tag in tags:
                list = list + [str_inst[tag]]
             
             csvwriter.writerow(list)
    empty_line = ['', '']
    csvwriter.writerow(empty_line)



def detailed_analysis(jobname, serverurl, projectkey):
    #Getting the issues from the sonarqube
    print projectkey
    url_detailed = serverurl + '/api/issues/search?componentKeys=' + projectkey + '&additionalFields=transitions'
    data_initial = getJasonresult(url_detailed)
    json_file_handler = "/home/shweta/PycharmProjects/ca_j4.json"
    writeToFile(json_file_handler, data_initial)
    json_string = readAndStore(json_file_handler, json_data={})
    csv_file_handler = open('/home/shweta/PycharmProjects/detailed_' + jobname + '.csv', 'a')
    csvwriter = csv.writer(csv_file_handler)
    Heading = ['List of issues']
    csvwriter.writerow(Heading)
    writeToCsv(json_string, csvwriter)
    csv_file_handler.close()

    json_d ={}
    code_smells = []
    vulnerability = []
    bugs = []
    for data in json_string:
            if data['type'] == 'CODE_SMELL':
                    code_smells.append(data)
            if data['type'] == 'VULNERABILITY':
                    vulnerability.append(data)
            if data['type'] == 'BUG':
                    bugs.append(data)
    data1 = {"code_smells": code_smells, "vulnerability":vulnerability, "bug":bugs }
    #storing the data at the elastic end
    #doc = {}
    #report = {}
    #report['sonar'] = json_string
    #doc['detailed'] = report
    #es = Elasticsearch(["http://10.71.71.18:9200"])
    #print doc
    #es.index(index = "reportstore", doc_type = jobname, id = build_id, body = doc)
    return data1
