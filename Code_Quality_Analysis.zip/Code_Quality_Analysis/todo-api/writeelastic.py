import json
import sys, os , time
sys.path.insert(0,'/home/shweta/PycharmProjects/Code')

sys.path.insert(0,'/etc/python')
sys.path.insert(0,'/etc/python2.7')
sys.path.append('/usr/lib/python2.7/dist-packages')
from elasticsearch import Elasticsearch
import gettotaljobs


# To add the form data to the elasticserach
def createdocument(task):
    emails = task['email']
    email_list = emails.split(",")
    #convert mails into list format
    print email_list
    task['email'] = email_list
    es = Elasticsearch(["http://10.71.71.18:9200"])  # connect with elasticsearch server
    #es.indices.create(index='jobdetails', ignore=400) # create index
    username = task['uname']  # uname will act the doctype
    result = es.search(index="jobdetails", doc_type=username)
    total = result['hits']['total']

    # timestamp is appended to keep the jobname unique.
    timest = int(time.time())
    timestp = str(timest)
    list_jobs = []   
    exists = 0

    # same method is to add new job or to edit the existing one.
    # so check if the job really exists .
    res = es.search(index="jobdetails", doc_type=username, size=total)
    for doc in res['hits']['hits']:
        list_jobs.append((doc['_id']).decode('utf-8'))
    for job in list_jobs:
	if task['jname'] in job:
            exists = 1
    if exists == 0:
         jobname = timestp+'_'+task['jname']  # add timestp to make jobname unique
    else :
         jobname = task['jname']

    task['jname'] = jobname 
    
    es.index(index="jobdetails", doc_type=username, id = jobname, body=task)
        
    # once the job is added we need to create it so execute the shell script 
    os.system('/home/shweta/PycharmProjects/mainscript.sh '+  username+' ' + jobname)

