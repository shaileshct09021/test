chmod -R 777 /var/lib/jenkins/workspace/
