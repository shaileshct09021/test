
from elasticsearch import Elasticsearch

# the count of builds API invokes the method 
# the total count is collected from elastic and returned
def getcount(jobname):
   es = Elasticsearch(["http://10.71.71.18:9200"])
   res = es.search(index="reportstore", doc_type=jobname)
   # for doc in res['hits']:
   #         (doc['total']).decode('utf-8')
   total = res['hits']['total']
   return total


