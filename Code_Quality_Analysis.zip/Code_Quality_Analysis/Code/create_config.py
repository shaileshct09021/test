
import configparser
#print 'Here I'
def setconfigParam(cmetrics,sonar,simian,cbo,nom,loc,eloc,cc,dit,lac,ccr,codesmell,bugs,issues,vulne,nbl,file):

	config = configparser.RawConfigParser()
	
	#health Param
	config.add_section('health')
	config.set('health','Class_metrices',cmetrics)
	config.set('health','Sonar_report',sonar)
	config.set('health','Duplication',simian)

	config.add_section('Class_metrices')
	#coupling between objects
	config.set('Class_metrices','CBO',cbo)
	#No of methods
	config.set('Class_metrices','NOM',nom)
	#Line Of Code
	config.set('Class_metrices','LOC',loc)
	#executable LOC
	config.set('Class_metrices','ELOC',eloc)
	#Cyclomatic Complexity
	config.set('Class_metrices','CC',cc)
	#Depth of inheritance tree
	config.set('Class_metrices','DIT',dit)
	#Lack of Cohesion
	config.set('Class_metrices','LAC',lac)
	#Comment to Code ratio
	config.set('Class_metrices','CCR',ccr)
	
	#Sonar analysis
	config.add_section('Sonar_report')
	config.set('Sonar_report','Code_smell',codesmell)
	config.set('Sonar_report','Bugs',bugs)
	config.set('Sonar_report','Issues',issues)
	config.set('Sonar_report','Vulnerabilities',vulne)

	#duplication
	config.add_section('Simian')
	config.set('Simian','NBL',nbl)
	#write config file
	with open(file,'wb') as configfile:
		config.write(configfile)


def getconfigParam(file,section,name):
	config = ConfigParser.RawConfigParser()
	config.read(file)
	return config.getfloat(section,name)
