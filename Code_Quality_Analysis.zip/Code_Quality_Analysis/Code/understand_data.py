#!/usr/bin/python3
import os, time
import sys
import csv
import json
from collections import defaultdict
import json
#sys.path.append("/usr/local/lib/python2.7/dist-packages/")
from elasticsearch import Elasticsearch
print ("TASK Create understand Data")
#os.system("export PATH=$PATH:/home/shweta/scitools/bin/linux64/python/")
#sys.path.append("/home/shweta/scitools/bin/linux64/python/")
#import understand
from jenkinsapi import jenkins
from jenkinsapi.jenkins import Jenkins

print("Initialize....")

def get_build(jobname):
    J = Jenkins("http://10.71.71.18:8080", "admin" ,"admin123")
    job = J[jobname]
    lgb = job.get_build_ids()
    return lgb.next()


def tree():
    return defaultdict(tree)

def default_to_regular(d):
    if isinstance(d, defaultdict):
        d = {k: default_to_regular(v) for k, v in d.iteritems()}
    return d

def understand_metrics(jobname):  

    with open('/var/lib/jenkins/workspace/'+jobname+'/mapping.json','r') as fund:
       und = json.loads(fund.read())
       #und = fund.read()
    #und = json.dumps(und)
    #print (type(und))
    #print (und)

    data1 = {}
    count= []
    fieldnames = []
    csvfile = open('/var/lib/jenkins/workspace/'+jobname+'/newDB.csv', 'r')
    #csvfile = open('/var/lib/jenkins/workspace/1475484377_Zportal/newDB.csv','r')
    fields = csvfile.readline()
    splitfields = fields.rstrip('\r\n').split(',')
    for key in splitfields:
        edited_key = key
        fieldnames.append(edited_key)
    fieldnames = tuple(fieldnames)
    reader = csv.DictReader( csvfile, fieldnames)

    rowc = 0
    for row in reader:
        rowc +=1
        name = str(row['Name']).replace('.','_')
        element = {name : row}
        count.append(element)
    data1["understand"] = count

##################################ALGO IMPLEMENTATION###########################################################
    c = -1
    for elem in data1['understand']:
        classname = elem.keys()
        healthcheck = 0
        c += 1
        #if 'Class' in elem[classname[0]]['Kind']:
        #    data = elem[classname[0]]
        #    loc = float(data['CountLineCode'])
        #    if loc > 0 :
        #        healthcheck = (float(data['CountLineCodeExe']) + float(data['CountDeclMethod'])+ float(data['PercentLackOfCohesion'])+float(data['MaxInheritanceTree']))
        #        healthcheck = float(healthcheck/loc)
        #        healthcheck = (healthcheck * 0.3) + (float(data['RatioCommentToCode'])* 0.3)
        #        healthcheck = healthcheck + ((float(data['AvgCyclomatic'])/loc )* 0.5 ) + ((float(data['CountClassCoupled'])/loc )* 0.2 )
        #    data1['understand'][c][classname[0]]['health'] = healthcheck

    d = tree()
    s2 = {}
    for s in data1["understand"]:
        names = s.keys()
        
        iter_node = d
        for name in names :
            if  s[name]["Kind"] == "Package":
                pack_data = {}
                getindex = s[name]["Name"]
                pack = getindex.split(".")
                size = len(pack)

                if size == 1:
                    iter_node[name]['values'] = s[name]
                else:
                    for node in pack:
                        iter_node = iter_node[node]
                    iter_node['values'] = s[name]
            #print (s[name])
            if "Class" in s[name]["Kind"]:
                pack_data = {}
                getindex = s[name]["Name"]
                pack = getindex.split(".")
                size = len(pack)
                t =" "
                for node in pack:
                    iter_node = iter_node[node]
                    t=node
                #print (und[t]) 
                iter_node['code_smell'] = und[t][0]
                iter_node['bugs'] = und[t][1]
                iter_node['vulnerabilities'] = und[t][2]
                iter_node['values'] = s[name]
    #print (d) 
    #d = default_to_regular(d)
    final = {}
    final["understand"] = d
    json.dump(d,open('/var/lib/jenkins/workspace/'+jobname+'/underst.json','w'))
    return final

job=sys.argv[1]
#x=understand_metrics('1475484377_Zportal')
x=understand_metrics(job)
print ("Understand metrices generated")
#print (x)
with open('/var/lib/jenkins/workspace/'+job+'/detailed.json','r') as fdetil:
     detil = json.loads(fdetil.read())

with open('/var/lib/jenkins/workspace/'+job+'/overview.json','r') as fov:
     ov = json.loads(fov.read())

with open('/var/lib/jenkins/workspace/'+job+'/report_pylint.json','r') as fpy:
     py = json.loads(fpy.read())

#build_id=31
build_id = get_build(job)

#server = jenkins.Jenkins("http://10.71.71.18:8080", username="admin" ,password="admin123")

#timestp=server[job]
#time1=(timestp.getbuild(build_id),get_timestamp())

time1 = int(time.time())

doc = {"overview" : {"sonar" : ov["overview"]},"detailed" : {"sonar" : {} ,"understand" : x["understand"]},"health" : ov["health"],"timestamp" : time1}


es = Elasticsearch(["http://10.71.71.18:9200"],timeout=70)
es.index(index="reportstore", doc_type=job, id=build_id, body=doc)

print ("Report Stored.")


os.system('sudo rm -rf /var/lib/jenkins/workspace/'+job+'/myproj/')


