from elasticsearch import Elasticsearch

#the list of builds are returned for the particular job
def listbuilds(jobname):
    builds = {}
    elastic = Elasticsearch(["http://10.71.71.18:9200"])
    res = elastic.search("reportstore", doc_type=jobname)
    for data in res['hits']['hits']:
        #builds.append(str(data['_id']))
        if 'health' in data['_source']:
            builds[str(data['_id'])] = data['_source']['health']
    #builds.sort()
    return builds

#listbuilds(sys.argv[1])

