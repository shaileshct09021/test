$(document).ready(function(){
		
		//For Signup
		$('#loginform').on('click', '#signup', function () {
		
	 
		   $('#myModal').modal('show');
		   
		   $('#ok').click(function(){
				 window.open("http://10.71.71.18:8080/job/Add_user/configure","add_user1");
			});
			
		  
		   $('#help').click(function(){
				$('#helpModal').modal('show');
				$('#myModal').modal('hide');
				
				$('#proceed').click(function(){
				$('#myModal').modal('hide');
				window.open("http://10.71.71.18:8080/job/Add_user/configure","add_user2");
				
			  });
			});
			
			

			
		});
		
		//For Setting Username
		$('#loginform').on('click', '#Login', function () {
		
				var name = $('#uname').val();
				
				var obj = new ClassUI();
				obj.Set_Login_User(name);
			
					
					
			});
			
		//ForCheck Username
		$('#loginform').on('blur', '#uname', function () {
					
					var uname = $(this).val();
					
					var obj = new ClassUI();
					obj.Check_Login(uname);
						
			});
		
		//Generate Login Form
		var obj = new ClassUI();
		obj.Load_Login_Form();
		
		});
		
