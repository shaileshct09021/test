import os
#import xml.etree.ElementTree as ET
from elasticsearch import Elasticsearch


# it is just the list of jobs belonging to particular user.
def list(user):
   list_jobs = []
   #print (user['user'])
   #match_by = user['user']
   #myPath = '/home/shweta/PycharmProjects/Jenkins_Jobs'
   #allFiles = os.listdir(myPath)
   #for module in allFiles:
      #if '.xml' in module:
          #print module
          #xmlfile = myPath+"/"+module
          #print xmlfile
          #tree = ET.parse(xmlfile)
          #username = tree.find('./uname').text
          #print username
          #if username == match_by: #if the word module is in the filename
               #dirToScreens = os.path.join(myPath, module)    
               #lists = module.replace('_',"")
               #lists = module[:-4]
               #print lists
               #list_jobs.append(lists)
   username = user['user']
   start = user['start']
   till = user['size']
   print username
   es = Elasticsearch(["http://10.71.71.18:9200"])
   res = es.search(index="jobdetails", doc_type=username, from_=start, size=till)
   for doc in res['hits']['hits']:
	list_jobs.append((doc['_id']).decode('utf-8'))
   print list_jobs
   return list_jobs
