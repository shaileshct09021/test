import requests
import json
import csv


# return the result generated from API in json format
def getJasonresult(req_url):
    resp = requests.get(req_url)
    return resp.json()


def writeToCsv(det_rep, csvwriter):
    list = []
    heading = ["The CODE_SMELLS with in the project"]
    csvwriter.writerow(heading)

    tags = ['status', 'severity', 'author', 'message', 'component', 'rule', 'debt', 'effort', 'key', 'creationDate',
            'updateDate']
    csvwriter.writerow(tags)
    code_sme = det_rep['code_smells']
    for str_inst in code_sme:
                # print str_inst
                del list[:]
                for tag in tags:
                    if tag in str_inst:

                        list = list + [str_inst[tag].encode('utf-8')]
                        #
                    else:
                        list = list + ['--']
                        # list = list + [str_inst[tag]]
                csvwriter.writerow(list)
    heading = ["The BUGS with in the project"]
    csvwriter.writerow(heading)

    tags = ['status', 'severity', 'author', 'message', 'component', 'rule', 'debt', 'effort', 'key', 'creationDate',
            'updateDate']
    csvwriter.writerow(tags)
    bug = det_rep['bugs']
    for str_inst in bug:
        # print str_inst
        del list[:]
        for tag in tags:
            if tag in str_inst:

                list = list + [str_inst[tag].encode('utf-8')]
                #
            else:
                list = list + ['--']
                # list = list + [str_inst[tag]]
        csvwriter.writerow(list)

    heading = ["The vulnerabilities with in the project"]
    csvwriter.writerow(heading)

    tags = ['status', 'severity', 'author', 'message', 'component', 'rule', 'debt', 'effort', 'key', 'creationDate',
            'updateDate']
    csvwriter.writerow(tags)
    bug = det_rep['vulnerabilities']
    for str_inst in bug:
        # print str_inst
        del list[:]
        for tag in tags:
            if tag in str_inst:

                list = list + [str_inst[tag].encode('utf-8')]
                #
            else:
                list = list + ['--']
                # list = list + [str_inst[tag]]
        csvwriter.writerow(list)

def detailed_analysis(jobname, serverurl, projectkey):
    # get all the codesmells

    code_sme_list = []
    # get no. of code_smells
    code = 'http://10.71.71.18:9000/api/resources?resource=' + projectkey + '&metrics=code_smells'
    data_initial = getJasonresult(code)

    no_cs = (data_initial[0]['msr'][0]['val'])
    # print no_cs
    if no_cs >500:
        no_pages = int(round(no_cs/500))
    else:
        no_pages = 1
    # print no_pages

    for no_page in range(no_pages+1):
        if no_page !=0:
            url_detailed = 'http://10.71.71.18:9000/api/issues/search?componentKeys=' + projectkey + '&types=CODE_SMELL&ps=500&p='+str(no_page)
            data_initial = getJasonresult(url_detailed)
            code_sme_list+=(data_initial['issues'])
            # print code_sme_list

    # get all the bugs
    bug_list = []
    # get no. of bugs
    bug = 'http://10.71.71.18:9000/api/resources?resource=' + projectkey + '&metrics=bugs'
    data_initial = getJasonresult(bug)

    no_bug = (data_initial[0]['msr'][0]['val'])
    # print no_bug

    if no_bug>500:
        no_pages = int(round(no_bug/500))
    else:
        no_pages = 1

    # print no_pages

    for no_page in range(no_pages+1):
        if no_page !=0:
            print no_page
            url_detailed = 'http://10.71.71.18:9000/api/issues/search?componentKeys=' + projectkey + '&types=BUG&ps=500&p='+str(no_page)
            data_initial = getJasonresult(url_detailed)
            bug_list+=data_initial['issues']
            # print bug_list



    # get all the vulnerability

    vul_list = []
    # get no. of vulnerability
    vul = 'http://10.71.71.18:9000/api/resources?resource=' + projectkey + '&metrics=bugs'
    data_initial = getJasonresult(vul)

    no_vul = (data_initial[0]['msr'][0]['val'])


    if no_vul>500:
        no_pages = int(round(no_vul/500))
    else:
        no_pages = 1

    # print no_pages

    for no_page in range(no_pages+1):
        if no_page !=0:
            # print no_page
            url_detailed = 'http://10.71.71.18:9000/api/issues/search?componentKeys=' + projectkey + '&types=VULNERABILITY&ps=500&p='+str(no_page)
            data_initial = getJasonresult(url_detailed)
            vul_list.append(data_initial['issues'])
            # print vul_list




    det_rep = {}
    det_rep['code_smells'] = code_sme_list
    det_rep['bugs'] = bug_list
    det_rep['vulnerabilities'] = vul_list
    print type(det_rep)
    csv_file_handler = open('/home/shweta/PycharmProjects/detailed_' + jobname + '.csv', 'w')
    csvwriter = csv.writer(csv_file_handler)
    Heading = ['List of issues']
    csvwriter.writerow(Heading)
    writeToCsv(det_rep, csvwriter)


    return det_rep
