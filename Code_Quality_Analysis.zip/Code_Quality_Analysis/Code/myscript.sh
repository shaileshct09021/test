sudo chmod -R 777 /var/lib/jenkins/workspace/1474623795_Valid/myproj
for file in /var/lib/jenkins/workspace/1474623795_Valid/myproj/*; do
   if [ -d $file ]; then
    for subfile in $file/*; do
        if [[ $subfile = *.py ]]; then
            pylint --output-format=json $subfile | tee pylint.json
            pylint --output-format=json -f parseable $subfile | tee pylint1.txt
        fi
    done
    fi
    if [[ $file = *.py ]]; then
       pylint --output-format=json $file | tee pylint.json
       pylint --output-format=json -f parseable $file | tee pylint1.txt
    fi
done
