import  os, sys
#import xml.etree.ElementTree as ET
from jenkinsapi import jenkins
from elasticsearch import Elasticsearch
import Create_job
import Configuring

#xml file storing the details of job
user = sys.argv[1]
job = sys.argv[2]
def main(username, jobname): # replace the parameters by file when using xml file
    server = jenkins.Jenkins('http://10.71.71.18:8080', username='admin', password='admin123')
    # xml file of the job details
    #tree = ET.parse(file)
    #username = tree.find('./uname').text
    #jobname = tree.find('./jobname').text
    #language = tree.find('./language').text
    #repo = tree.find('./repository_url').text
    #branch = tree.find('./branch').text

    #working on elasticsearch
    es = Elasticsearch(["localhost:9200"])

    result = es.get("jobdetails", jobname, doc_type=username)
    details = result[u'_source']
    language = details['language']
    repo = details['url']
    branch = details['branch']
    schedule = details['minute']+" "+details['hours']+" "+details['day']+" "+details['month']+" "+details['weekday']

    # creation of the job on the server using a jenkins api
    Create_job.create_job(server, jobname, language)

    #shell to change the permissions of the job folder in workspace required  during configurations
    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')



    #if language is python we need to configure it by both pylint and sonar
    if language == 'python':
        os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')
        #configuring the job using a temporary config file
        Configuring.configure_pylint(schedule, server, jobname, repo, branch, username)
        #server.build_job(jobname, None)

    else:
        #if other language just the configuration for the sonar
        Configuring.configure_sonar(schedule, language, server, jobname, repo, branch, username)
        #server.build_job(jobname, None)

#main(file)
main(user, job)
