	var username = localStorage.getItem("username");
	 if(username == null)
	 {
	 window.open("Home.html","_self") 
	 }

$(document).ready(function(){
	
  
	 
		var obj = new ClassUI();
	    
		obj.Load_User_Nav();
		obj.Load_User_Page();
		obj.ProcessUser();
   
		$('a.pmenu').click(function(){
			   var id = this.id;
			   $('a.pmenu').prop('class','pmenu');
			   $('#'+id).prop('class','pmenu active');
			   
		});
		
		
		
		$('#logout').click(function()
		  {
		  localStorage.clear();
		  window.open("Home.html","_self")
		  });
		
		
		var parsedTemplate ='';
		var exampleValues = '';
		
		
	
		$('#add_new_job').click(function(){
			$('#visualisation').attr('height','0');
			document.getElementById('visualisation').innerHTML='';
			var t1 = new ClassProject();
			t1.formProject('add','');

		});
		
		$('#myhome').click(function(){

				document.getElementById('output_div').innerHTML='';
				document.getElementById('visualisation').innerHTML='';
				
				$('#visualisation').attr('height','500');
				//InitChart();console.log('graph');
				
		});
		
		var parsedTemplate ='';
		var exampleValues = '';
		
		$('#list_jobs').click(function(){
				$('#visualisation').attr('height','0');
				document.getElementById('visualisation').innerHTML='';
				localStorage.setItem("page_start", 0);
				localStorage.setItem("page_size", 10);
				
				list_jobs();
				
 
		});
		
	
	});
	
	function list_jobs()
	{
		var t1 = new ClassProject();
		t1.listProject();
				
	}
	
	
	$('#user_page').on('click', 'i.edit_job', function () {//For Edit window only
		
		
		var c = $(this).attr('id').replace("edit_", "");
		
			var t1 = new ClassProject();
			t1.formProject('edit',c);
					
		});
		
	$('#user_page').on('click', 'i.run_job', function () {//For Edit window only
		
		
		var c = $(this).attr('id').replace("run_", "");
		
		
		var t1 = new ClassBuild(c,'');
		t1.runBuild();
					
		});
	
	$('#user_page').on('click', 'i.config_job', function () {//For Edit window only
		
		
		var c = $(this).attr('id').replace("config_", "");
		
		
			var t1 = new ClassProject();
			t1.configProject(c);
					
		});
		
		
	$('#user_page').on('click', 'i.fa-toggle-down', function () {//For Edit window only
		
		
		var c = $(this).attr('id').replace("view_build_", "");
		
		localStorage.setItem("jobpage_start", 0);
		localStorage.setItem("jobpage_size", 10);
				
		var t1 = new ClassBuild(c,'');
		t1.listBuild();
					
		});
		
	$('#user_page').on('click', 'i.compare_job', function () {//For Edit window only
		
		
		var c = $(this).attr('id').replace("compare_", "");
		var t = $(this).attr('title').split("_");
		
		var t1 = new ClassBuild(c,t[0]);
		t1.ClassWiseCompare(t[0],t[1]);
					
		});
    
	/*$('#user_page').on('click', 'i.fa-toggle-down', function () {//For Edit window only
		
		
		var c = $(this).attr('id').replace("view_build_", "");
		//console.log(c);

			$(this).prop('class','fa fa-toggle-up build_toggle');
		
					
		});*/
		
	$('#user_page').on('click', 'i.fa-toggle-up', function () {//For Edit window only
		
		
		var c = $(this).attr('id').replace("view_build_", "");
		//console.log(c);
		
			$(this).prop('class','fa fa-toggle-down build_toggle');
					
		});
		
	$('#user_page').on('click', 'i.fa-plus-circle', function () {//For Edit window only
		

			$(this).prop('class','fa fa-minus-circle fa-fw');
		
					
		});
		
	$('#user_page').on('click', 'i.fa-minus-circle', function () {//For Edit window only
		
		
			$(this).prop('class','fa fa-plus-circle fa-fw');
					
		});
		
	$('#user_page').on('click', 'i.fa-external-link-square', function () {//For Edit window only
		
			window.open("http://10.71.71.18:9000/code/index?id=1475501183_SmartQed_server_2.1#/1475501183_SmartQed_server_2.1%3A1475501183_SmartQed_%20server_2.1%2Fsrc%2Fmain%2Fjava%2Fcom%2FsmartQED%2Fqedspace%2Fwebsocket%2Fresponse%2FClueResponse.java","add_user1");
					
		});
		
	$('#user_page').on('click', 'label.tree-toggler', function () {//For Edit window only
		
		
		$(this).parent().children('ul.tree').toggle(300);
					
		});
		
	$('#user_page').on('click','li.stab',function(){
		
		
		var tabid = $(this).attr("id").replace("s_", "");
		$(".tab-pane.active").prop("class","tab-pane");
		$("#"+tabid).prop("class","tab-pane active");
		$(".stab.active").prop("class","stab");
		$(this).prop("class","stab active");
	});
	

	
	$('#user_page').on('click', 'span.icon', function () {//For Edit window only
		
		
		var cl = $(this).prop("class");
		
		if(cl=="icon expand-icon fa fa-folder-open")
		{
			$(this).prop('class','icon expand-icon fa fa-folder');	
			
		}
		else if(cl=="icon expand-icon fa fa-folder")
		{
			$(this).prop('class','icon expand-icon fa fa-folder-open');	
			
		}
		
		});
	$('#user_page').on('click', 'span.cicon', function () {//For Edit window only
		
		
		var ccl = $(this).prop("class");
		
		var navid = $(this).attr("id").replace("nav_", "");
		//.log($(this).attr("id"));
		if(ccl=="cicon icon_"+navid+" expand-icon glyphicon glyphicon-minus")
		{
			$(".icon_"+navid).prop('class','cicon icon_'+navid+' expand-icon glyphicon glyphicon-plus');
			$(".navList_"+navid).prop('style','display:none;');
			
			
			
		}
		else if(ccl=="cicon icon_"+navid+" expand-icon glyphicon glyphicon-plus")
		{
			$(".icon_"+navid).prop('class','cicon icon_'+navid+' expand-icon glyphicon glyphicon-minus');	
			
					$(".navList_"+navid).prop('style','display:block;');
			
			
		}
		
		});
		
	$('#user_page').on('click', 'span.matrix', function () {//For Edit window only
		
			var c = $(this).attr('id').replace("matrix_", "");
			$('.matrix.selectedlist').prop('class','matrix');	
			$('#matrix_'+c).prop('class','matrix selectedlist');	
			//console.log('#tblmatrix'+c);
			$('div.tblmatrix').prop('style','display:none');	
			$('#tblmatrix'+c).prop('style','display:block');
            

        var usname = localStorage.getItem("username");
		var jobname = $('#jobname').val();
		var build_id = $('#build_id').val();
		var source = $(this).attr('title');
        var formData = JSON.stringify({ "jobname":jobname,"username" : usname});
    
        $.ajax({
           url: 'http://10.71.71.18:5000/todo/api/v1.0/getconfigdetails',
           dataType: 'json',
           type: 'post',
           contentType: 'application/json',
           data: formData,

           success: function(response){
                
				//console.log(response)
				
				var classMat = response.configs.class_metrics;
				var simian = response.configs.simian;
				var sonar = response.configs.sonar_report;
				
				
                
								var obj = new ClassHealth();
								obj.setHealthConfig(classMat.weightage,sonar.weightage,simian.weightage);
								obj.setHealthClassConfig(classMat.parameters.cbo,classMat.parameters.cc,classMat.parameters.ccr,classMat.parameters.dit,classMat.parameters.eloc,classMat.parameters.lco,classMat.parameters.loc,classMat.parameters.nom);
								obj.setHealthSonarConfig(sonar.parameters.bugs,sonar.parameters.code_smell,sonar.parameters.issues,sonar.parameters.vulnerabilities);
								obj.setHealthSimianConfig(simian.parameters.nbl);
								
								//obj.setProjectConfig(classMat.weightagesonar.weightage,simian.weightage);
								//var tt = obj.calcHealthClass(a.CountClassCoupled,a.AvgCyclomatic,a.RatioCommentToCode,a.MaxInheritanceTree,a.CountLineCodeExe,a.PercentLackOfCohesion,a.CountLineCode,a.CountDeclMethod);
								//obj.calcHealthSonar(sonar.parameters.bugs,sonar.parameters.code_smell,sonar.parameters.issues,sonar.parameters.vulnerabilities);
								//obj.calcHealthSimian(simian.parameters.nbl);
							   //console.log("Here"+jobname+"--"+build_id);;
								var formData1 = JSON.stringify({ "jobname":jobname,"build_id" : build_id,"source":source});
								$.ajax({
									   url: 'http://10.71.71.18:5000/todo/api/v1.0/getclassdetails',
									   dataType: 'json',
									   type: 'post',
									   contentType: 'application/json',
									   data: formData1,

									   success: function(response1){
										   var pack_class = source.split('.');
										   var pack = pack_class[source.length-1];
										   console.log(response1);
										   var y = response1['result']['detailed']['understand'];
										   var z = {};
										   var tt = y;
										   for(x of pack_class)
										   {
											    //console.log(tt[x]);
											    z = tt[x];
												tt = z;
												
										   }
										   class_m = tt['values'];
										   sonar = tt['code_smell']; 
										   //console.log(sonar);
										   var class_h = obj.calcHealthClass(class_m.CountClassCoupled,class_m.AvgCyclomatic,class_m.RatioCommentToCode,class_m.MaxInheritanceTree,class_m.CountLineCodeExe,class_m.PercentLackOfCohesion,class_m.CountLineCode,class_m.CountDeclMethod);
										   console.log("Class Helth: "+class_h);
										   var code_smell = obj.getLOCCodeSmell(tt['code_smell']);
										   //console.log(code_smell);
										   var bugs=0,issues=0,Vulnera=0;
										   //var bugs = obj.getLOCbugs(tt['bugs']);
										   // var issues = obj.getLOCissues(tt['issues']);
										   //var Vulnera = obj.getLOCVulneral(tt['Vulneral']);
										   
										   var sonar_h = obj.calcHealthSonar(bugs,code_smell,issues,Vulnera,class_m.CountLineCode);
										   console.log("Sonar Helth: "+sonar_h);
							thealth = 	(parseFloat(class_h)+parseFloat(sonar_h))/2;
							var totalhealth ='';			 
							
							if(parseFloat(thealth)>=7.5)
							{
						
								totalhealth ='<span class="label label-success" style="float:right">Very Good</span>';
						
							}
							else if(parseFloat(thealth)>=5.0)
							{
						
								totalhealth ='<span class="label label-info" style="float:right">Good</span>';
						
							}
							else if(parseFloat(thealth)>=2.5)
							{
						
								totalhealth = '<span class="label label-warning" style="float:right">Average</span>';
						
							}
							else
							{
						
								totalhealth = '<span class="label label-danger" style="float:right">Bad</span>';
						
							}
					
									$('#health'+c).html(totalhealth);
									
										},
										   error: function( jqXhr, textStatus, errorThrown ){
											console.log("error");
											
										  }
										});	
           },
           error: function( jqXhr, textStatus, errorThrown ){
            console.log("error");
            
          }
        });	

		

	});
	
	
	$('#user_page').on('click', 'span.matrixCLASS', function () {//For Edit window only
			
				var c = $(this).attr('id').replace("matrix_", "");
				var cc = $('.matrixCLASS.selectedlist').attr('id').replace("matrix_", "");
				$('.matrixCLASS.selectedlist').prop('class','matrixCLASS CLASS_'+cc);	
				$('.CLASS_'+c).prop('class','matrixCLASS CLASS_'+c+' selectedlist');	
				console.log('.metricesCLASS_'+c);
				$('div.tblmatrix').prop('style','display:none');	
				$('.metricesCLASS_'+c).prop('style','display:block');
				

		});		
	$('#user_page').on('click', 'a.pageno', function () {//For Edit window only
		
		
		var c = parseInt($(this).attr('id').replace("page", ""));
		//console.log(c);
		var size = parseInt(localStorage.getItem("page_size"));
		var page_start = (size*c);
		if(page_start==0)
		{
			page_start=0;
		}
		else
		{
			page_start=page_start;
		}
		localStorage.setItem("page_start",page_start);
		
		list_jobs();
					
		});
		
	$('#user_page').on('click', 'a.jobpageno', function () {//For Edit window only
		
		
		var c = parseInt($(this).attr('id').replace("page", ""));
		//console.log(c);
		var size = parseInt(localStorage.getItem("page_size"));
		var page_start = (size*c);
		if(page_start==0)
		{
			page_start=0;
		}
		else
		{
			page_start=page_start;
		}
		localStorage.setItem("jobpage_start",page_start);
		
		var j = $(this).attr('title');
		console.log(page_start,j);
		var t1 = new ClassBuild(j,'');
		t1.listBuild();
					
		});
		
	$('#user_page').on('click', '#config_update', function(){
		
				var classmetrices = $('#classmetrices').val();
				var und = $('#und').val();
				var dulpicate = $('#dulpicate').val();
				
				
				var couple_obj = $('#couple_obj').val();
				var cy_comp = $('#cy_comp').val();
				var code_ratio = $('#code_ratio').val();
				var d_tree = $('#d_tree').val();
				var eloc = $('#eloc').val();
				var lack_cohesion = $('#lack_cohesion').val();
				var loc = $('#loc').val();
				var no_method = $('#no_method').val();
				
				var bugs = $('#bugs').val();
				var code_smell = $('#code_smell').val();
				var issues = $('#issues').val();
				var Vulnera = $('#Vulnera').val();
				
				var nlb = $('#nlb').val();
				
				var jname = $('#jname').val();
				
				
				var t5 = new ClassProject();
				t5.setProjectConfig(classmetrices,und,dulpicate);
				t5.setProjectClassConfig(couple_obj,cy_comp,code_ratio,d_tree,eloc,lack_cohesion,loc,no_method);
				t5.setProjectSonarConfig(bugs,code_smell,issues,Vulnera);
				t5.setProjectSimianConfig(nlb);
				t5.saveProjectConfig(jname);
				
				
	});
	
	$('#user_page').on('click', '#submit1', function () {//For Edit window only
		
		
		
        var c = $(this).attr('name'); 
			
		var uname,jname,url,branch,email,language,minute,day,hours,weekday,month;
        
        uname =$('#uname').val();
        
		jname = $('#jname').val();
		jname_view = $('#jname_view').val();
		
        url = $('#url').val();
        branch = $('#branch').val();
        email = $('#email').val();
        language = $('#language').val();
        minute = $('#minute').val();
        day = $('#day').val();
        hours = $('#hours').val();
        weekday = $('#weekday').val();
        month = $('#month').val();
		if (ValidateForm(uname,jname_view,url,branch,email,language) == true){
		//$('#pleaseWaitDialog').modal('show');	
		
		var t1 = new ClassProject();
		t1.setProjectData(uname,jname,url,branch,email,language);
		t1.setProjectSchedule(minute,day,hours,weekday,month);
		t1.saveProject();
		
				if(c=='update')
				{
					document.getElementById('output_div').innerHTML='<div class="alert alert-success"><strong>Success!</strong> Project will be Update Shortly.</div>';	
				}
				else
				{
					document.getElementById('output_div').innerHTML='<div class="alert alert-success"><strong>Success!</strong> Project will Be Added Shortly.</div>';	
				}
		}
					
		});
		
		
	    
	
	
	
	$('#user_page').on('click', 'i.view_detail', function () {//For Edit window only
		
		$('#pleaseWaitDialog').modal('show');	
		var c = $(this).attr('id').replace("view_", "");
		var d = $(this).attr('title');
		var t1 = new ClassBuild(c,d);
		//t1.DreportBuild();
		t1.ClassWiseReport();
		$('#pleaseWaitDialog').modal('hide');
		
					
		});
		
	function processData_1(c,data) {
        var lines = data.split(/\r\n|\n/);

        //Set up the data arrays
        var time = [];
        var data1 = [];
        var data2 = [];
        var data3 = [];

        var headings = lines[1].split(','); // Splice up the first row to get the headings
		var h1 =headings[1];
		var h2 =headings[2];
		var h3 =headings[3];
		var h4 =headings[4];
		
		var lines1 = [];
		var tab_no = 1;
		var tbl= '<h4>Detail Report:</h4>';
		
		tbl +='<div class="tabbable"><ul class="nav nav-tabs"><li class="active"><a href="#tab1" data-toggle="tab">PYLINT</a></li><li><a href="#tab2" data-toggle="tab">CODE SMELLS</a></li><li><a href="#tab3" data-toggle="tab">VULNERABILTY</a></li><li><a href="#tab4" data-toggle="tab">BUGS</a></li></ul><div class="tab-content">';
		
		tbl+='<div class="tab-pane active" id="tab1"><table class="table dataTables_scrollBody dataTable"><thead><tr><th>'+h1+'</th><th>'+h2+'</th><th>'+h3+'</th><th>'+h4+'</th><tr></thead><tbody>';
		
        for (var j=2; j<lines.length-1; j++) {
			
        var values = lines[j].replace(/\//g, " ").split(','); // Split up the comma seperated values
         
        if(values[0]=="The CODE_SMELLS with in the project" || values[0]=="The BUGS with in the project" || values[0]=="The VULNERABILTY with in the project")
		{	
			tab_no++;
			
			headings = lines[j+1].split(',');
			h1 =headings[1];
			h2 =headings[2];
			h3 =headings[3];
			h4 =headings[4];

			tbl+= '</tbody></table></div><div class="tab-pane" id="tab'+tab_no+'"><table class="table dataTables_scrollBody dataTable"><thead><tr><th>'+h1+'</th><th>'+h2+'</th><th>'+h3+'</th><th>'+h4+'</th><tr></thead><tbody>';
			j=j+1;
			values = lines[j+1].replace(/\//g, " ").split(',');
		}
		
		   
		   
		   var v1 =values[1];
		   var v2 =values[2];
		   var v3 =values[3];
		   var v4 =values[4];
          //console.log(v1+"-"+v2+"-"+v3);
		  tbl +='<tr><td>'+v1+'</td><td>'+v2+'</td><td>'+v3+'</td><td>'+v4+'</td></tr>';
		  
		   
		   
        }
		tbl +='</tbody></table></div></div></div>';
	    
		
		//console.log(tbl);
        document.getElementById('output_div').innerHTML=tbl;
    }
	

	
	
	$('#user_page').on('click', 'i.view_overview', function () {//For Edit window only
		
		$('#pleaseWaitDialog').modal('show');	
		var c = $(this).attr('id').replace("view_", "");
		var d = $(this).attr('title');
		var t1 = new ClassBuild(c,d);
		t1.OreportBuild();
		$('#pleaseWaitDialog').modal('hide');	

					
	});
	
	
	$('#user_page').on('change', '#jname_view', function () {//For Edit window only
	
	  var str;
	  if($('#jname_pre').val()!='')
	  {
	  str = $('#jname_pre').val()+'_'+$(this).val();
	  }
	  else
	  {
	  str = $(this).val();
	  }
	  
	  $('#jname').val(str);
	  
	});
	
	$('#user_page').on('blur', '.form-control.input-md', function () {//For Edit window only
		
		
		var c = $(this).attr('id');
		//console.log('#div_'+c);
		if(this.value=="")
		{
			$('#div_'+c).prop('class','form-group has-error');
			$('#sdiv_'+c).prop('class','glyphicon glyphicon-remove form-control-feedback');
			
		}
		else
		{	
				if(c=='email')
				{
					if (this.value.indexOf("@", 0) < 0)
					{
						$('#div_'+c).prop('class','form-group has-error');
						$('#sdiv_'+c).prop('class','glyphicon glyphicon-remove form-control-feedback');
					}
					else if (this.value.indexOf(".", 0) < 0)
					{
						$('#div_'+c).prop('class','form-group has-error');
						$('#sdiv_'+c).prop('class','glyphicon glyphicon-remove form-control-feedback');
						
					}
					else
					{
						$('#div_'+c).prop('class','form-group has-success');
						$('#sdiv_'+c).prop('class','glyphicon glyphicon-ok form-control-feedback');
						
					}
				
				}
				else
				{
					$('#div_'+c).prop('class','form-group has-success');
					$('#sdiv_'+c).prop('class','glyphicon glyphicon-ok form-control-feedback');
				}
				
				if(c=='url')
				{
					
						if(ValidURL($(this).val())== true)
						{
							$('#div_'+c).prop('class','form-group has-success');
							$('#sdiv_'+c).prop('class','glyphicon glyphicon-ok form-control-feedback');
						}
						else
						{
							$('#div_'+c).prop('class','form-group has-error');
							$('#sdiv_'+c).prop('class','glyphicon glyphicon-remove form-control-feedback');
						}
						
				}
				if(c=='branch')
				{
						if(ValidBranch($(this).val())== true)
						{
							$('#div_'+c).prop('class','form-group has-success');
							$('#sdiv_'+c).prop('class','glyphicon glyphicon-ok form-control-feedback');
						}
						else
						{
							$('#div_'+c).prop('class','form-group has-error');
							$('#sdiv_'+c).prop('class','glyphicon glyphicon-remove form-control-feedback');
						}
				}
				
				if(c=='jname_view')
				{
						if(ValidJobname($(this).val())== true)
						{
							$('#div_'+c).prop('class','form-group has-success');
							$('#sdiv_'+c).prop('class','glyphicon glyphicon-ok form-control-feedback');
						}
						else
						{
							$('#div_'+c).prop('class','form-group has-error');
							$('#sdiv_'+c).prop('class','glyphicon glyphicon-remove form-control-feedback');
						}
						
				}
		}
				
		});
		
		$('#user_page').on('blur', 'select.form-control', function () {//For Edit window only
			
			var c = $(this).attr('id');
			if(c!='language')
			{
				if(this.value=="")
				{
					$('#div_'+c).prop('class','form-group has-feedback');
				}
				else
				{
					$('#div_'+c).prop('class','form-group has-success');
				}
			}
			
			if(c =="dulpicate" || c=="code_smell" || c=="classmetrices")
			{
				var v1= parseInt($("#classmetrices").val());
				var v2= parseInt($("#und").val());
				var v3= parseInt($("#dulpicate").val());
				
				if(eval(v1+v2+v3)==100)
				{	
					console.log(eval(v1+v2+v3));
					$('#div_classmetrices').prop('class','form-group has-success');
					$('#div_und').prop('class','form-group has-success');
					$('#div_dulpicate').prop('class','form-group has-success');
					$('#config_update').prop('disabled',false);
				}
				else
				{
					console.log(eval(v1+v2+v3));
					$('#div_classmetrices').prop('class','form-group has-error');
					$('#div_und').prop('class','form-group has-error');
					$('#div_dulpicate').prop('class','form-group has-error');
					$('#config_update').prop('disabled',true);
				}
			}
		});
		
	function processData(data) {
        var lines = data.split(/\r\n|\n/);

        //Set up the data arrays
        var time = [];
        var data1 = [];
        var data2 = [];
        var data3 = [];

        var headings = lines[3].split(','); // Splice up the first row to get the headings
		var h1 =headings[0];
		var h2 =headings[1];
		var h3 =headings[2];
	
		
		var lines1 = [];
		var Headline = lines[1].replace(/"/g, " ");
		var tbl= '<div><h4>Overview Report:</h4><b>The rating by pylint:</b><p>'+Headline+'</p><table class="table dataTables_scrollBody dataTable"><thead><tr><th>'+h1+'</th><th>'+h2+'</th><th>'+h3+'</th><tr></thead><tbody>';
		
		var Headline = lines[1].replace(/\//g, " ").split(',');
		
		
        for (var j=4; j<lines.length-1; j++) {
			
           var values = lines[j].replace(/\//g, ">").split(','); // Split up the comma seperated values
           
		  
		   
		   var v1 =values[0];
		   var v2 =values[1];
		   var v3 =values[2];
		   
          //console.log(v1+"-"+v2+"-"+v3);
		  tbl +='<tr><td>'+v1+'</td><td>'+v2+'</td><td>'+v3+'</td></tr>';
		  
		  
		   
        }
		tbl +='</tbody></table>';
	    
		
		//console.log(tbl);
        document.getElementById('output_div').innerHTML=tbl;
    }
function ValidateForm(uname,jname,url,branch,email,language)
{
    
 

    if (uname == "")
    {
       // window.alert("Please enter your name.");
		$('#div_uname').prop('class','form-group has-error');
		$('#div_uname').focus();
        return false;
    }
   if  (jname == "" || ValidJobname(jname)== false)
    {
       // window.alert("Please enter your jobname");
        $('#div_jname').prop('class','form-group has-error');
		$('#div_jname').focus();
        return false;
    }
    if (url == "" || ValidURL(url)== false)
    {
       // alert("Please enter the url");
        $('#div_url').prop('class','form-group has-error');
		$('#div_url').focus();
        return false;
    }

	if (branch == "" || ValidBranch(branch)== false)
    {
       // window.alert("Please provide an appropriate branch.");
		$('#div_branch').prop('class','form-group has-error');
		$('#div_branch').focus();
        return false;
    }
	
    if (email == "")
    {
       // window.alert("Please enter a valid e-mail address.");
        $('#div_email').prop('class','form-group has-error');
		$('#div_email').focus();
        return false;
    }
    if (email.indexOf("@", 0) < 0)
    {
       // window.alert("Please enter a valid e-mail address.");
        $('#div_email').prop('class','form-group has-error');
		$('#div_email').focus();
        return false;
    }
    if (email.indexOf(".", 0) < 0)
    {
       // window.alert("Please enter a valid e-mail address.");
		$('#div_email').prop('class','form-group has-error');
		$('#div_email').focus();
        return false;
    }

    if(language.value == "")
    {
       // window.alert("Please enter the language.");
        $('#div_language').prop('class','form-group has-error');
		$('#div_language').focus();
        return false;
    }
    return true;
   }
   
function ValidURL(str) {
	
  var regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;
  if(!regex .test(str)) {
   //alert("Please enter valid URL.");
    return false;
  } else {
    return true;
  }
}
function ValidBranch(str) {
	
  /*var regExp = /^[A-Za-z0-9]+$/;
  if(!regExp.test(str.replace("_", ""))) {
  // alert("Please enter valid Branch.");
    return false;
  } else {*/
    return true;
  //}
}

function ValidJobname(str) {
	
  var regExp = /^[A-Za-z0-9]+$/;
  if(!regExp.test(str.replace("_", ""))) {
  // alert("Please enter valid Branch.");
    return false;
  } else {
    return true;
  }
}
function toCamelCase(str){
	
  if(str.indexOf("_",0)>0)
  {
	return str.split('_').map(function(word){
		return word.charAt(0).toUpperCase() + word.slice(1);
	}).join(' ');
  }
  else
  {
	return str.split(' ').map(function(word){
		return word.charAt(0).toUpperCase() + word.slice(1);
	}).join(' ');  
  }
  
}
function csvTojs(csv) {
  var lines=csv.split("\n");
  var result = [];
  var headers = lines[0].split(",");

  for(var i=1; i<lines.length; i++) {
    var obj = {};

    var row = lines[i],
      queryIdx = 0,
      startValueIdx = 0,
      idx = 0;

    if (row.trim() === '') { continue; }

    while (idx < row.length) {
      /* if we meet a double quote we skip until the next one */
      var c = row[idx];

      if (c === '"') {
        do { c = row[++idx]; } while (c !== '"' && idx < row.length - 1);
      }

      if (c === ',' || /* handle end of line with no comma */ idx === row.length - 1) {
        /* we've got a value */
        var value = row.substr(startValueIdx, idx - startValueIdx).trim();

        /* skip first double quote */
        if (value[0] === '"') { value = value.substr(1); }
        /* skip last comma */
        if (value[value.length - 1] === ',') { value = value.substr(0, value.length - 1); }
        /* skip last double quote */
        if (value[value.length - 1] === '"') { value = value.substr(0, value.length - 1); }

        var key = headers[queryIdx++];
        obj[key] = value;
        startValueIdx = idx + 1;
      }

      ++idx;
    }

    result.push(obj);
  }
  return result;
}
