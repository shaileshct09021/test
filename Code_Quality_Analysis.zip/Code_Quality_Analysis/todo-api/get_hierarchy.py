from elasticsearch import Elasticsearch


def get_hierarchy(jobname, build_id):
    elas = Elasticsearch(["http://10.71.71.18:9200"])
    #print (elas)
    res = elas.get(index="reportstore", doc_type=jobname, id=build_id)
    return res
