from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from smtplib import SMTP
import smtplib
import sys, os


def mail_the_report(jobname,email_list):
    recipients = email_list
    emaillist = [elem.strip().split(',') for elem in recipients]
    msg = MIMEMultipart()
    msg['Subject'] = "testing application"
    msg['From'] = 'pragati.wagh@gslab.com'
    msg['Reply-to'] = 'pragati.wagh@gslab.com'

    msg.preamble = 'Multipart message.\n'


    
    part = MIMEText("Hi, please find the attached file containing the report")
    msg.attach(part)
    part = MIMEApplication(open('/home/shweta/PycharmProjects/detailed_'+jobname+'.csv', 'rb').read())
    part.add_header('Content-Disposition', 'attachment', filename='detailed_'+jobname+'.csv')
    msg.attach(part)
    part = MIMEApplication(open('/home/shweta/PycharmProjects/overview_'+jobname+'.csv', 'rb').read())
    part.add_header('Content-Disposition', 'attachment', filename='overview_'+jobname+'.csv')
    msg.attach(part)


    server = smtplib.SMTP("smtp.gmail.com:587")
    server.ehlo()
    server.starttls()
    server.login("pragati.wagh@gslab.com", "gslab_account")

    server.sendmail(msg['From'], emaillist, msg.as_string())
    

    os.remove('/home/shweta/PycharmProjects/overview_'+jobname+'.csv')
    os.remove('/home/shweta/PycharmProjects/detailed_'+jobname+'.csv')
