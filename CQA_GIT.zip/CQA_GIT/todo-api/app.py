
#!flask/bin/python

from flask import Flask, jsonify, abort, request, make_response, url_for
import sys, os, json
#sys.path.append('/usr/local/lib/python2.7/dist-packages')
sys.path.insert(0,'/etc/python')
sys.path.insert(0,'/etc/python2.7')
sys.path.append('/usr/local/lib/python2.7/dist-packages')
import writexml
import writeelastic
import listfiles
import jobinformation
import listofbuilds
import getreport
import buildproject
import lxml.builder
import gettotaljobs
import userlist
app = Flask(__name__)

def add_cors_header(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Authorization, Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'POST, GET, PUT, PATCH, DELETE, OPTIONS'
    return response

app.after_request(add_cors_header)



tasks = [ {
        'id': 1,
        'title': u'Buy groceries',
        'description': u'Milk, Cheese, Pizza, Fruit, Tylenol',
        'done': False
    },
    {
        'id': 2,
        'title': u'Learn Python',
        'description': u'Need to find a good Python tutorial on the web',
        'done': False
    }

]


@app.route('/todo/api/v1.0/tasks', methods=['POST'])
def create_task():
    task={

            #'userid' : request.json['userid'],
            'uname' : request.json['uname'],
            'jname' : request.json['jname'],
            'url': request.json['url'],
            'branch' : request.json['branch'],
            'email' : request.json['email'],
            'language' : request.json['language'],
            'minute' : request.json['minute'],
            'day' : request.json['day'],
            'hours' : request.json['hours'],
            'weekday' : request.json['weekday'],
            'month' : request.json['month']

    }

    #writexml.writeToFile(task)
    writeelastic.createdocument(task)
    return jsonify({'task': task}), 201

@app.route('/todo/posttask', methods = ['GET'])
def hello():
    argument = request.args.get('jobname')
    command = 'sudo /home/shweta/PycharmProjects/postshell.sh ' + argument
    print argument
    os.system(command)
    return "Success",201 



@app.route('/todo/api/v1.0/list', methods = ['POST'])
def listFiles():
    users={
    'user' : request.json['username'],
    'start' : request.json['start'],
    'size' : request.json['size']
}
    jobs = listfiles.list(users)
    return jsonify({'jobs':jobs}),200
    #return jsonify({'jobs' : users['user']}),200

@app.route('/todo/api/v1.0/getjobdetails', methods = ['POST'])
def jobdetails():
    jobname = request.json['jobname']
    username = request.json['username']
    jobdetail = jobinformation.jobinfo(jobname,username)
    return jsonify({'details': jobdetail}),200

@app.route('/todo/api/v1.0/getreport', methods = ['POST'])
def report():
    jobname = request.json['jobname']
    build_id = request.json['build_id']
    result = getreport.get(jobname, build_id)
    return jsonify({'result' : result}),200


@app.route('/todo/api/v1.0/getbuilds', methods = ['POST'])
def builds():
   jobname = request.json['jobname']
   builds = listofbuilds.listbuilds(jobname)
   return jsonify({'builds' : builds }),200

@app.route('/todo/api/v1.0/buildproject', methods = ['POST'])
def startbuild():
   jobname = request.json['jobname']
   buildproject.build_project(jobname)
   return jsonify({'status' : 'started'}),200

@app.route('/todo/api/v1.0/jobcount', methods = ['POST'])
def count():
    user= request.json['username']
    count = gettotaljobs.getcount(user)
    return jsonify({'count':count}),200
    #return jsonify({'jobs' : users['user']}),200

@app.route('/todo/api/v1.0/userexist', methods = ['POST'])
def userexistence():
    user= request.json['username']
    exist = userlist.userexist(user)
    return jsonify({'exist':exist}),200
    #return jsonify({'jobs' : users['user']}),200



if __name__ == '__main__':
    app.run(debug=True, threaded=True)

