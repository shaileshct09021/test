import email_sender
import overview
import detailed
import auto_jenkin


job_status = auto_jenkin.automation()
'''if job_status == "SUCCESS":
    overview.overview_analysis()
    detailed.detailed_analysis()
    email_sender.mail_the_report()
'''