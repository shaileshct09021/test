from elasticsearch import Elasticsearch

def set_conf(username, jobname, config):
    elas = Elasticsearch(["http://10.71.71.18:9200"])
    doc = {'doc': { 'configuration' : config}}
    #print doc
    state = elas.update(index='jobdetails', doc_type=username, id=jobname, body = doc)
    #(index = "my-index_112",doc_type= "hack_locus",id = 2,body= doc )
    return state
