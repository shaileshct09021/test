from elasticsearch import Elasticsearch

def comparelogic(jobname):
    builds_id = []
    elastic = Elasticsearch(['http://10.71.71.18:9200'])
    res = elastic.count(index='reportstore',doc_type=jobname)
    count = res['count']
    res = elastic.search("reportstore", doc_type=jobname, from_=0, size=count)
    
    for data in res['hits']['hits']:
         builds_id.append(int(data['_id']))
    builds_id = sorted(builds_id)
    print builds_id
    builds = builds_id[count-2: ]
    print builds
    #return builds

comparelogic('1474623795_Valid')
