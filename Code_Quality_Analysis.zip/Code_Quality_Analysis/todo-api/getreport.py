from elasticsearch import Elasticsearch
import sys


# the report of the particular jobs particular build.
# executed when an api is requested
def get(jobname, build_id):
    elas = Elasticsearch(["http://10.71.71.18:9200"])
    res = elas.get_source("reportstore", doc_type=jobname, id=build_id)
    return res


#get(sys.argv[1],sys.argv[2])
