import os
import xml.etree.ElementTree as ET
from elasticsearch import Elasticsearch

def jobinfo(jobname, username):
   #tree = ET.parse('/home/shweta/PycharmProjects/Jenkins_Jobs/'+file)
   #email_list = []
   #root = tree.getroot()
   #for element in root.iter('email_list'):
       #for mail in element:
        # print mail.text 
        # print type(mail.text)
        # email_list.append(mail.text)
   #print email_list
   #email_string = ",".join(email_list)
   
   #schedule = tree.find('./schedule').text
   #schedule_list = str(schedule).split(' ')
   #print schedule_list
   #details = {'repo' : tree.find('./repository_url').text,
   #          'branch' : tree.find('./branch').text,
   #          'language' : tree.find('./language').text,
   #          'email' : email_string ,
   #          'minute' : schedule_list[0],
   #          'hour' : schedule_list[1],
   #          'day' : schedule_list[2],
   #          'month' : schedule_list[3],
   #          'weekday' : schedule_list[4] }
   
   es = Elasticsearch(["http://10.71.71.18:9200"])
    
   result = es.get("jobdetails",jobname,doc_type=username)
   details = result[u'_source']
   email_list = details['email']
   email_string = ",".join(email_list)
   details['email'] = email_string

   return details
