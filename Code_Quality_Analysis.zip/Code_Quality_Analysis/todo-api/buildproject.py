from jenkinsapi import jenkins
# to trigger the build explictly to the jenkins.
# the jobname is passed as the jenkinsapi require jobname
def build_project(jobname):
   server = jenkins.Jenkins('http://10.71.71.18:8080', username='admin', password='admin123')
   server.build_job(jobname)
