#import jenkins 
import gitlab
import base64

from jenkinsapi import jenkins
import xml.etree.ElementTree as ET


#establish connection get an instance of server.
def get_server_instance():

    jenkins_url = 'http://10.71.71.18:8080'
    server = jenkins.Jenkins(jenkins_url, username = 'nikhil.mehta@gslab.com', password = '***')
    return server


def get_job_details():

    server = get_server_instance()

    for single_job in server.get_jobs():
        job_instance = server.get_job(single_job[0])

        if job_instance.name == 'locus':
            urll = jenkins.Job.get_scm_url(job_instance)

            url = urll[0]
            return url
           
def send_properties_of_sonar(id, git):

    file_data = git.getfile(id, 'PROPERTIES.txt', 'master')

    propertiess = base64.b64decode (file_data[u'content'])

    server = get_server_instance()

    for single_job in server.get_jobs():
        job_instance = server.get_job(single_job[0])
        print job_instance
        if job_instance.name == 'locus':
            print job_instance.name
            config = job_instance.get_config()


            with open('prop.xml', 'w') as file_writer:
                 file_writer.write(config)

            tree = ET.parse('prop.xml')

            root = tree.getroot()

            for builder in root.iter('builders'):
                for child in builder.iter('hudson.plugins.sonar.SonarRunnerBuilder'):
                    for prop in child.iter('properties'):
                        new_rank = propertiess

                        prop.text = new_rank

            tree.write("prop.xml")
            file_reader = open('prop.xml','r')

            conf_file=file_reader.read()
            print conf_file
            jenkins.Job.update_config(job_instance, conf_file)

            running = job_instance.is_queued_or_running()
            server.build_job('locus',None)

            while running:
                sleep(1)
                running = job_instance.is_queued_or_running()
       
           
            latestBuild = job_instance.get_last_build()
            return latestBuild
            
def automation():

    url = get_job_details()


    git = gitlab.Gitlab('http://gitlab.gslab.com', 'zASukUAVsAyy_FhNCBWY')
    project =  list(git.getall(git.getprojects))
    for project_element in project:
         repository_url = project_element[u'http_url_to_repo']
         repository_url = repository_url.replace('gitlab', 'gitlab.gslab.com', 1)
         if url == repository_url:
            id = project_element[u'id']
    


    latest_Build = send_properties_of_sonar(id, git)
    return latest_Build.get_status()
   

       
