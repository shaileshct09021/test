import xml.etree.ElementTree as ET

# list of all users who have signed up to the system
def userexist(username):
    exist = False
    tree = ET.parse('/var/lib/jenkins/credentials.xml')
    users = tree.findall('.//username')
    for user in users:
        print user.text
        if username == user.text:
            exist = True
            print user.text
    return exist
