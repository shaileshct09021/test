python /home/shweta/PycharmProjects/Code/post_build.py $1
