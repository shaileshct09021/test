function ClassProject()
{

	//properties of project
	var uname;
	var jname;
	var url;
	var branch;
	var email;
	var language;
	var minute;
	var day;
	var hours;
	var weekday;
	var month;
	var classmetrices,und,dulpicate,couple_obj,cy_comp,code_ratio,d_tree,eloc,lack_cohesion,loc,no_method;
	var bugs,code_smell,issues,Vulnera,nlb;
	//method for set Project Details
	this.setProjectData = function(uname,jname,url,branch,email,language)
	{
		this.uname=uname;
		this.jname=jname;
		this.url=url;
		this.branch=branch;
		this.email=email;
		this.language=language;
	}
	//method for set Project Config
	this.setProjectConfig = function(classmetrices,und,dulpicate)
	{
		this.classmetrices=classmetrices;
		this.und=und;
		this.dulpicate=dulpicate;
	}
	this.setProjectClassConfig = function(couple_obj,cy_comp,code_ratio,d_tree,eloc,lack_cohesion,loc,no_method)
	{
		this.couple_obj=couple_obj;
		this.cy_comp=cy_comp;
		this.code_ratio=code_ratio;
		this.d_tree=d_tree;
		this.eloc=eloc;
		this.lack_cohesion=lack_cohesion;
		this.loc=loc;
		this.no_method=no_method;
	}
	this.setProjectSonarConfig = function(bugs,code_smell,issues,Vulnera)
	{
		this.bugs=bugs;
		this.code_smell=code_smell;
		this.issues=issues;
		this.Vulnera=Vulnera;
	}
	this.setProjectSimianConfig = function(nlb)
	{
		this.nlb=nlb;
	}
	//method for set Project Schedule
	this.setProjectSchedule = function(minute,day,hours,weekday,month)
	{
		this.minute=minute;
		this.day=day;
		this.hours=hours;
		this.weekday=weekday;
		this. month=month;
	}
	//method for add or edit project form
	this.formProject = function(actmode,c){

		var parsedTemplate ='';
		var exampleValues = '';
		
		//console.log('Class');
					$.ajax({
						url:'/Code_Quality_Analysis/add_new_job.html',
						type:'GET',
						async: true,
						success: function(json) {

							parsedTemplate = _.template(json);
							exampleValues = parsedTemplate({act:actmode,id:c});
							document.getElementById('output_div').innerHTML=exampleValues;
							
							}
						});

	}

	//method for save or update proj config Project
	this.saveProjectConfig = function(jobname){

	    var classparam = {"cbo":this.couple_obj,"cc":this.cy_comp,"ccr":this.code_ratio,"dit":this.d_tree,"elco":this.eloc,"lco":this.lack_cohesion,"loc":this.loc,"nom":this.no_method};
		var simianparam = {"nbl":this.nbl};
		var sonarparam =  {"bugs":this.bugs,"code_smell":this.code_smell,"issues":this.issues,"vulnerabilities":this.Vulnera};
		
		var usname = localStorage.getItem("username");
		
		var formData = JSON.stringify({"username":usname,"jobname":jobname,"configs":{"class_metrics":{"parameters":classparam,"weigthage":this.classmetrices},"simian":{"parameters":simianparam,"weigthage":this.dulpicate},"sonar_report":{"parameters":sonarparam,"weigthage":this.und}}});
					$.ajax({
					    url: 'http://10.71.71.18:5000/todo/api/v1.0/setconfigdetails',
						dataType: 'json',
						type: 'post',
						contentType: 'application/json',
						data: formData,
						success: function(json) {

							console.log('Class success');
							$('#myModal').modal('show');
							
							}
						
					
					});
					
					document.getElementById('output_div').innerHTML='<div class="alert alert-success"><strong>Success!</strong> Project Config saved successfully.</div>';
	}
	
	//method for save or update project
	this.saveProject = function(){

		var formData = JSON.stringify({"uname":this.uname,"jname":this.jname,"url":this.url,"branch":this.branch,"email":this.email,"language":this.language,"minute":this.minute,"day":this.day,"hours":this.hours,"weekday":this.weekday,"month":this.month});
		
		
					$.ajax({
					    url: 'http://10.71.71.18:5000/todo/api/v1.0/tasks',
						dataType: 'json',
						type: 'post',
						contentType: 'application/json',
						data: formData,
						success: function(json) {

							console.log('Class success');
							$('#myModal').modal('show');
							
							},
				        error: function( jqXhr, textStatus, errorThrown ){
							//console.log("error");
							document.getElementById('output_div').innerHTML='<div class="alert alert-danger"><strong>Error!</strong> Internal API Error.</div>';
						}
					
					});
	}

    this.listProject = function(){

			var usname = localStorage.getItem("username");
			var start = localStorage.getItem("page_start");
			var size = localStorage.getItem("page_size");;
			console.log(start+":"+size);
		    var formData = JSON.stringify({ "username" : usname,"start": start,"size": size});
		
				$.ajax({
				   url: 'http://10.71.71.18:5000/todo/api/v1.0/list',
				   dataType: 'json',
				   type: 'post',
				   contentType: 'application/json',
				   data: formData,

				   success: function( response ){
					   //console.log("success");
					  
					   //console.log(response);
					   
						$.ajax({
						url:'/Code_Quality_Analysis/view_list_jobs.html',
						type:'GET',
						async: false,
						success: function(json) {
							
							parsedTemplate = _.template(json);
							exampleValues = parsedTemplate({list:response});
							document.getElementById('output_div').innerHTML=exampleValues;
							
							}
						});	

					},
				    error: function( jqXhr, textStatus, errorThrown ){
						console.log("error");
						document.getElementById('output_div').innerHTML='<div class="alert alert-danger"><strong>Error!</strong> Internal API Error.</div>';
					}
				});
    }

	this.configProject = function(c){

		var parsedTemplate ='';
		var exampleValues = '';
		
		//console.log('Class');
					$.ajax({
						url:'/Code_Quality_Analysis/set_config_job.html',
						type:'GET',
						async: true,
						success: function(json) {

							parsedTemplate = _.template(json);
							exampleValues = parsedTemplate({id:c});
							document.getElementById('output_div').innerHTML=exampleValues;
							
							}
						});

	}
}
