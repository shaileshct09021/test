
import json
#import Main
import sys, os , time
sys.path.insert(0,'/home/shweta/PycharmProjects/Code')
sys.path.insert(0,'/etc/python')
sys.path.insert(0,'/etc/python2.7')
sys.path.append('/usr/lib/python2.7/dist-packages')
# import Main
import lxml.builder
import lxml.etree as LE1  

def writeToFile(task):
    unique = int(time.time())
    uniq1 = str(unique)
    if os.path.isfile("/home/shweta/PycharmProjects/Jenkins_Jobs/"+ task['jname']+".xml"):
        filename1 = task['jname']
    else:
        filename1 = uniq1 +'_'+ task['jname']
    E = lxml.builder.ElementMaker()
    ROOT = E.job
    emaillist = task['email']
    email2 = emaillist.split(",")
    email_List= []
    for i in email2:
        email_List.append(i)
    print type(email_List)
    print email_List
    schedule_value = task['minute'] + " "+ task['hours']+ " " +task['day']+" " +task['month']+ " " + task['weekday']
    the_doc = ROOT(
    
               # E.userid(task['userid']),
                E.uname(task['uname']),
                E.jobname(filename1),
                E.repository_url(task['url']),
                E.branch(task['branch']),
                E.email_list(),
                E.language(task['language']),
		E.schedule(schedule_value),
                E.projectKey(task['jname']+'_'+task['branch']) ,
                E.projectName(task['jname']),
                E.sources(task['jname']+'project'),
                E.sourceEncoding('UTF-8')
                )

    root = the_doc.find('./email_list')
    for j in email_List:
         email = LE1.Element('email')
         email.text = j
         root.append(email)

    filename='/home/shweta/PycharmProjects/Jenkins_Jobs/'+ filename1 + '.xml'

    with open(filename,'w') as filewriter:
        filewriter.write(lxml.etree.tostring(the_doc))
   # Main.main(filename)
    os.system('/home/shweta/PycharmProjects/mainscript.sh '+  filename)
#writeToFile({"userid":"12","uname":"Pragati","password":"gslab","jname":"Feedup12","url":"http://gitlab.gslab.com/Pragati/Code_Quality_Analysis.git","branch":"master","email":"pragati.wagh@gslab.com","language":"python"})

