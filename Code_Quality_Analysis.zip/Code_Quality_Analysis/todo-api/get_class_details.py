from elasticsearch import Elasticsearch

def getclassdetails(jobname, buildid, source):
    elas = Elasticsearch(['http://10.71.71.18:9200'])
    print jobname , buildid , source
 
    res = elas.get_source(index='reportstore', doc_type=jobname, id=buildid, _source=['detailed.understand.'+source])
    return res


#getclassdetails('1475484377_Zportal','35','com.zautomate.zportal.controller.AdminController')
