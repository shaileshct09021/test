
#!flask/bin/python

from flask import Flask, jsonify, abort, request, make_response, url_for
import sys, os, json
#sys.path.append('/usr/local/lib/python2.7/dist-packages')
sys.path.insert(0,'/etc/python')
sys.path.insert(0,'/etc/python2.7')
sys.path.append('/usr/local/lib/python2.7/dist-packages')
import writexml
import writeelastic
import listfiles
import jobinformation , get_health_config
import listofbuilds
import getreport
import buildproject
import lxml.builder
import sorted_builds
import gettotaljobs
import gettotalbuilds
import userlist
import get_hierarchy, get_class_details
import get_buildid_compare
import set_health_config

#import projconfigparam

app = Flask(__name__)

# For handling the permissions from remote source 
def add_cors_header(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Authorization, Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'POST, GET, PUT, PATCH, DELETE, OPTIONS'
    return response

app.after_request(add_cors_header)



tasks = [ {
        'id': 1,
        'title': u'Buy groceries',
        'description': u'Milk, Cheese, Pizza, Fruit, Tylenol',
        'done': False
    },
    {
        'id': 2,
        'title': u'Learn Python',
        'description': u'Need to find a good Python tutorial on the web',
        'done': False
    }

]

# an API to add a new job or to edit the existing job .It just gets the data from
# the form and submits it . The data is passed over for further processing.
@app.route('/todo/api/v1.0/tasks', methods=['POST'])
def create_task():
    with open("/home/shweta/PycharmProjects/default_configuration.json",'r') as handle:
         configure = handle.read()

    configuration = json.loads(configure)
    


    task={

            #'userid' : request.json['userid'],
            'uname' : request.json['uname'],
            'jname' : request.json['jname'],
            'url': request.json['url'],
            'branch' : request.json['branch'],
            'email' : request.json['email'],
            'language' : request.json['language'],
            'minute' : request.json['minute'],
            'day' : request.json['day'],
            'hours' : request.json['hours'],
            'weekday' : request.json['weekday'],
            'month' : request.json['month'],
	    'configuration' : configuration['health_configuration']
    }

    #writexml.writeToFile(task)
    writeelastic.createdocument(task)
    return jsonify({'task': task}), 201

# Whenever a new job is being build it needs to perform various actions. 
# In post build we pass the jobname which is required.
@app.route('/todo/posttask', methods = ['GET'])
def postbuildtask():
    argument = request.args.get('jobname')
    command = 'sudo /home/shweta/PycharmProjects/postshell.sh ' + argument
    print argument
    os.system(command)
    return "Success",201 


# This returns the list of jobs for a particular user.
# It requires user name and the range of jobs from the list.
@app.route('/todo/api/v1.0/list', methods = ['POST'])
def listFiles():
    users={
    'user' : request.json['username'],
    'start' : request.json['start'],
    'size' : request.json['size']
}
    jobs = listfiles.list(users)
    return jsonify({'jobs':jobs}),200
    #return jsonify({'jobs' : users['user']}),200

# This job information API will give the details related to the job.
# The information entered by the user.
@app.route('/todo/api/v1.0/getjobdetails', methods = ['POST'])
def jobdetails():
    jobname = request.json['jobname']
    username = request.json['username']
    jobdetail = jobinformation.jobinfo(jobname,username)
    return jsonify({'details': jobdetail}),200


@app.route('/todo/api/v1.0/getconfigdetails', methods = ['POST'])
def configdetails():
    jobname = request.json['jobname']
    username = request.json['username']
    configurations = get_health_config.get_conf(username, jobname)
    return jsonify({'configs': configurations}),200

@app.route('/todo/api/v1.0/setconfigdetails', methods = ['POST'])
def setconfigdetails():
    jobname = request.json['jobname']
    username = request.json['username']
    configs = request.json['configs']
    set_health_config.set_conf(username, jobname, configs)
    return "success",201

# The data collected from the tools after building jobs through the tools.
# This data is displayed to the user.
@app.route('/todo/api/v1.0/getreport', methods = ['POST'])
def report():
    jobname = request.json['jobname']
    build_id = request.json['build_id']
    result = getreport.get(jobname, build_id)
    return jsonify({'result' : result}),200


@app.route('/todo/api/v1.0/gethierarchy', methods = ['POST'])
def hierarchy():
    jobname = request.json['jobname']
    build_id = request.json['build_id']
    result = get_hierarchy.get_hierarchy(jobname, build_id)
    return jsonify({'result' : result}),200

@app.route('/todo/api/v1.0/getclassdetails', methods = ['POST'])
def classdetails():
    jobname = request.json['jobname']
    build_id = request.json['build_id']
    source = request.json['source']
    result = get_class_details.getclassdetails(jobname, build_id, source)
    return jsonify({'result' : result}),200




# A job has many builds. The analysis reports are stored for each build
# So the list of builds to browse through the data of build.
@app.route('/todo/api/v1.0/getbuilds', methods = ['POST'])
def builds():
   jobname = request.json['jobname']
   start = request.json['start']
   size = request.json['size']
   builds = listofbuilds.listbuilds(jobname, start, size)
   return jsonify({'builds' : builds }),200


@app.route('/todo/api/v1.0/getsortedbuilds', methods = ['POST'])
def sortedbuilds():
   jobname = request.json['jobname']
   start = request.json['start']
   size = request.json['size']
   builds = sorted_builds.listsortedbuilds(jobname, start, size)
   return jsonify({'builds' : builds }),200




@app.route('/todo/api/v1.0/compare', methods = ['POST'])
def comparebuilds():
   jobname = request.json['jobname']
   #start = request.json['start']
   #size = request.json['size']
   builds = get_buildid_compare.compare(jobname)
   return jsonify({'builds' : builds }),200


# If the user wishes to trigger build from the interface he can do it.
# The job name is passed and the build is triggered.
@app.route('/todo/api/v1.0/buildproject', methods = ['POST'])
def startbuild():
   jobname = request.json['jobname']
   buildproject.build_project(jobname)
   return jsonify({'status' : 'started'}),200

# The total count of jobs for a particular job.
@app.route('/todo/api/v1.0/jobcount', methods = ['POST'])
def count():
    user= request.json['username']
    count = gettotaljobs.getcount(user)
    return jsonify({'count':count}),200
    #return jsonify({'jobs' : users['user']}),200


# The count of builds for a particular job
@app.route('/todo/api/v1.0/buildcount', methods = ['POST'])
def buildcount():
    jobname= request.json['jobname']
    count = gettotalbuilds.getcount(jobname)
    return jsonify({'jobcount':count}),200

# To check if the user exists so as to check the user is signed to the system.
@app.route('/todo/api/v1.0/userexist', methods = ['POST'])
def userexistence():
    user= request.json['username']
    exist = userlist.userexist(user)
    return jsonify({'exist':exist}),200
    #return jsonify({'jobs' : users['user']}),200

if __name__ == '__main__':
    app.run(debug=True, threaded=True)

