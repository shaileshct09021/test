import xml.etree.ElementTree as ET
from jenkinsapi import jenkins
import gitlab
import os

#def get_gitjob_id(repo):
#    git = gitlab.Gitlab('http://gitlab.gslab.com', 'zASukUAVsAyy_FhNCBWY')
#    proj = list(git.getall(git.getprojects))
#    for p in proj:
#        repository_url = p[u'http_url_to_repo']
#        repository_url = repository_url.replace('gitlab', 'gitlab.gslab.com', 1)
#        if repo == repository_url:
#            id = p[u'id']
#            return id

def get_credentialID(username):
    #get the credentials based on the username given by the user from the in-built credentials file of jenkins
    tree = ET.parse("/var/lib/jenkins/credentials.xml")
    root = tree.getroot()
    for element in root:
        for subelement in element:
            for parent in subelement.iter('java.util.concurrent.CopyOnWriteArrayList'):
                for child in parent:
                    for details in child.iter('username'):
                        if details.text == username:
                            id = child.find('id')
                            return id.text


def configure_pylint(schedule, server, jobname, repo, branch, username):
    #configuring the pylint by just implying changes in the temporary config file   
    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')

    if os.access('/var/lib/jenkins/workspace/'+jobname,os.W_OK) == 'False':
        os.system('sudo /home/shweta/PycharmProjects/shellfile.sh') 

    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh') 

    with open('/home/shweta/PycharmProjects/setup.py','r') as filereader:
        setup = filereader.read()
    # a setup file to execute the script successfully
    filepath = '/var/lib/jenkins/workspace/'+jobname+'/setup.py'
    with open(filepath, 'w') as f:
        f.write(setup)
    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')
    with open('/home/shweta/PycharmProjects/README.rst', 'r') as filereader:
        readme = filereader.read()

    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')
    filepath = '/var/lib/jenkins/workspace/'+jobname+'/README.rst'
    with open(filepath, 'w') as f:
        f.write(readme)
    # few parameters required for configurations
    #branch = '*/'+branch

    #tree1 = ET.parse(file)

    key = jobname + '_' + branch
    name = jobname #tree1.find('./projectName').text
    #schedule = tree1.find('./schedule').text
    branch = '*/'+branch

    language = 'py'
    sources = 'myproj'
    encoded = 'UTF-8' #tree1.find('./sourceEncoding').text

    propertiess = 'sonar.projectKey =' + key + '\n sonar.projectName =' + name + '\n sonar.projectVersion = 1.0 ' + '\n sonar.language =' + language + '\n sonar.sources =' + sources + '\n sonar.sourceEncoding = '+ encoded 

    #branch='*/'+branch
    tree = ET.parse('/home/shweta/PycharmProjects/pythonfile.xml')
    tree.find('.//hudson.plugins.git.UserRemoteConfig/url').text = repo

    tree.find('.//hudson.plugins.git.BranchSpec/name').text = branch
    tree.find('.//hudson.plugins.git.UserRemoteConfig/credentialsId').text = get_credentialID(username)
    tree.find('.//hudson.plugins.sonar.SonarRunnerBuilder/properties').text = propertiess
    tree.find('.//relativeTargetDir').text = sources
    tree.find('.//hudson.triggers.TimerTrigger/spec').text = schedule
    tree.write('/home/shweta/PycharmProjects/pythonfile.xml')
    with open('/home/shweta/PycharmProjects/pythonfile.xml') as reader:
        configure = reader.read()
    #apply the configurations to the job 
    for single_job in server.get_jobs():
        job_instance = server.get_job(single_job[0])
        if job_instance.name == jobname:
            job_instance.update_config(configure)
            


def configure_sonar(schedule, language, server, jobname, repo, branch, username):
    #configuring the job for the sonar tool
    # few parameters required 
    #tree1 = ET.parse(file)
    key = jobname + '_' + branch #tree1.find('./projectKey').text
    name = jobname #tree1.find('./projectName').text
    #schedule = tree1.find('./schedule').text

    #language = tree1.find('./language').text
    #if language == 'python':
       # language = 'py'
    sources = jobname + '_ ' + branch #tree1.find('./sources').text
    encoded = 'UTF-8' #tree1.find('./sourceEncoding').text

    propertiess = 'sonar.projectKey =' + key + '\n sonar.projectName =' + name + '\n sonar.projectVersion = 1.0 ' + '\n sonar.language =' + language + '\n sonar.sources =' + sources + '\n sonar.sourceEncoding = ' + encoded  #= base64.b64decode(file_data[u'content'])

    tree = ET.parse('/home/shweta/PycharmProjects/sonarfile.xml')
    tree.find('.//hudson.plugins.git.UserRemoteConfig/url').text = repo
    tree.find('.//hudson.plugins.git.UserRemoteConfig/credentialsId').text = get_credentialID(username)
    tree.find('.//hudson.plugins.git.BranchSpec/name').text = branch
    tree.find('.//hudson.plugins.sonar.SonarRunnerBuilder/properties').text = propertiess
    tree.find('.//relativeTargetDir').text = sources
    tree.find('.//hudson.triggers.TimerTrigger/spec').text = schedule

 

    tree.write('/home/shweta/PycharmProjects/sonarfile.xml')
    with open('/home/shweta/PycharmProjects/sonarfile.xml', 'r') as reader:
        configure = reader.read()
    #apply the configurations to the job 
    for single_job in server.get_jobs():
        job_instance = server.get_job(single_job[0])
        if job_instance.name == jobname:
            job_instance.update_config( configure)


