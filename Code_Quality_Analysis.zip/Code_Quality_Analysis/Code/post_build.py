
import os, time, sys
import json
import pylintreport
#import understand_data
import healthcheck
import email_sender, detailedrep, overview
#import xml.etree.ElementTree as ET
#import create_config
#sys.path.append("/usr/local/lib/python2.7/dist-packages/")
from jenkinsapi import jenkins
from jenkinsapi.jenkins import Jenkins
from elasticsearch import Elasticsearch


def get_build(jobname):
    J = Jenkins('http://10.71.71.18:8080', "admin", "admin123")
    job = J[jobname]
    lgb = job.get_build_ids()
    return lgb.next()



#file = sys.argv[1]
jobname = sys.argv[1]
#if '_pylint' in file:
    #file=file.replace("_pylint","",1)
#elif '_sonar' in file:
    #file=file.replace("_sonar","",1)
configfile='/var/lib/jenkins/workspace/'+jobname+'/exampleconfigfile.cfg'
#if os.path.isfile(configfile) == True:
#create_config.setconfigParam('40','30','30','20','10','20','10','20','5','10','5','40','20','20','20','6',configfile)
#paramloc = create_config.getconfigParam(configfile,'Class_metrices','LOC')
#print paramloc


build_id = get_build(jobname)

#time.sleep(100)

serverurl = 'http://10.71.71.18:9000'
#tree = ET.parse(file)

#jobname = tree.find('./jobname').text

es = Elasticsearch(["http://10.71.71.18:9200"])
result = es.get("jobdetails", jobname)

details = result['_source']
#email_list = []
language = details['language'] #tree.find('./language').text

#print type(details['email'])
email_list = details['email']
#root = tree.getroot()
#for element in root.iter('email_list'):
#     for mail in element:
#         email_list.append(mail.text)

#email_list = ['waghprags@gmail.com' , 'pragati.wagh@gslab.com']
key = jobname +'_'+ details['branch'] #tree.find('./projectKey').text
#print key
#get the timestamp of particular build
server = jenkins.Jenkins('http://10.71.71.18:8080', username='admin', password='admin123')

timestp = server[jobname]
time1 = (timestp.get_build(build_id).get_timestamp())

if language == 'python':
    while os.path.isfile('/var/lib/jenkins/workspace/' + jobname + '/pylint.json') == False:
        time.sleep(5)
    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')
    os.system('sudo /home/shweta/PycharmProjects/shellfile.sh')
    time.sleep(100)
    #print understd
    ov_rpt = overview.overview_analysis(jobname, serverurl, key)
    json.dump(ov_rpt,open("/var/lib/jenkins/workspace/"+jobname+"/overview.json","wb"))

    statement = int(ov_rpt['lines'])
    pylnt = pylintreport.generate_report(jobname,statement)
    json.dump(pylnt,open("/var/lib/jenkins/workspace/"+jobname+"/report_pylint.json","wb"))

    dt_rpt = detailedrep.detailed_analysis(jobname, serverurl, key)
    json.dump(dt_rpt,open("/var/lib/jenkins/workspace/"+jobname+"/detailed.json","wb"))

    #undcmd = "sudo python3 /home/shweta/Code_Quality_Analysis/start.py " +dt_rpt +" " + json.dump(jobname)
    #os.system(undcmd)

    understd ={"understand":{}} # understand_data.understand_metrics(jobname)

    #doc = {"overview" : {"sonar" : ov_rpt['overview'], "pylint" : pylnt['score']}, "detailed" : {"sonar" : dt_rpt, "pylint" : pylnt['detailed'], "understand" : understd }, "health" : ov_rpt['health'], "timestamp" : time1}
    #report = {}
    #report['sonar'] = json_string
    #doc['detailed'] = report
    #es = Elasticsearch(["http://10.71.71.18:9200"])
    #print doc
    #es.index(index="reportstore", doc_type=jobname, id=build_id, body=doc)

    #time.sleep(100)
    #healthcheck.health(jobname, build_id)
    #email_sender.mail_the_report(jobname, email_list)

else:
    #overview.overview_analysis(jobname, serverurl, key)
    #detailed.detailed_analysis(jobname, serverurl, key)
    understd = {} #understand_data.understand_metrics()


    dt_rpt = detailedrep.detailed_analysis(jobname, serverurl, key)
    #print dt_rpt
    #with open("/var/lib/jenkins/workspace/"+jobname+"/detailed.json","w",encoding="utf-8") as f:
    #     json.dumps(dt_rpt,f,ensure_ascii=False).encode("utf8")

    json.dump(dt_rpt,open("/var/lib/jenkins/workspace/"+jobname+"/detailed.json","wb"))


    ov_rpt = overview.overview_analysis(jobname, serverurl, key)

    pylnt = {}

    json.dump(pylnt,open("/var/lib/jenkins/workspace/"+jobname+"/report_pylint.json","wb"))


    #with open("/var/lib/jenkins/workspace/"+jobname+"/overview.json","w") as f1:
    #     json.dumps(ov_rpt,f1).encode("utf8")
    json.dump(ov_rpt,open("/var/lib/jenkins/workspace/"+jobname+"/overview.json","wb"))
    #doc = {"overview" : {"sonar" : ov_rpt['overview'] }, "detailed" : {"sonar" : dt_rpt ,"understand" : understd }, "health" : ov_rpt['health'], "timestamp" : time1 }
    #report = {}
    #report['sonar'] = json_string
    #doc['detailed'] = report
    #es = Elasticsearch(["http://10.71.71.18:9200"])
    #print doc
    #es.index(index="reportstore", doc_type=jobname, id=build_id, body=doc)
    #healthcheck.health(jobname, build_id)

    #time.sleep(100)

    #email_sender.mail_the_report(jobname, email_list)




