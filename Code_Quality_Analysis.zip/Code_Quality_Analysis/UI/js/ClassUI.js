function ClassUI(){

	this.Load_Login_Form = function(){
		console.log('Class');
		var parsedTemplate ='';
		var exampleValues = '';
		
		
			$.ajax({
			url:'Loginform.html',
			type:'GET',
			async: false,
			success: function(json) {

				parsedTemplate = _.template(json);
				exampleValues = parsedTemplate({act:'view'});
				document.getElementById('loginform').innerHTML=exampleValues;
				
				}
			});
	}
	
	this.Check_Login = function(uname){
		console.log('Class');
		var formData = JSON.stringify({"username":uname});
			$.ajax({
					    url: 'http://10.71.71.18:5000/todo/api/v1.0/userexist',
						dataType: 'json',
						type: 'post',
						contentType: 'application/json',
						data: formData,
						success: function(json) {

							//console.log(json['exist']);
                            if(json['exist']==true)
							{
								localStorage.setItem("username", uname);
								localStorage.removeItem("jobname");
								$('#Login').prop('disabled',false);
								//$('#div_uname').prop('class','form-group has-success');
							}
							else
							{
								$('#Login').prop('disabled',true);
								//$('#div_uname').prop('class','form-group has-error');
							}
							},
				        error: function( jqXhr, textStatus, errorThrown ){
						console.log("error");
						$('#Login').prop('disabled',true);
						//document.getElementById('output_div').innerHTML='<div class="alert alert-danger"><strong>Error!</strong> Internal API Error.</div>';
					}
			});
		
	}
	
	this.Set_Login_User = function(username){
			console.log('Class');
			localStorage.setItem("username", username);
			localStorage.removeItem("jobname");
	
	}
	
	this.ProcessUser =function(){

	 
	var username = localStorage.getItem("username");
	 
	if(username == null)
	 {
		window.open("Home.html","_self") 
	 }
	else
	 {	 
		document.getElementById("user").innerHTML ="Welcome, " + username;
	 }
	 
	 $('#myhome').prop('class','pmenu active');
	}
 
 
	this.Load_User_Nav = function()
	{
		
		var parsedTemplate ='';
		var exampleValues = '';
		
		
			$.ajax({
			url:'/Code_Quality_Analysis/User_navigation.html',
			type:'GET',
			async: false,
			success: function(json) {

				parsedTemplate = _.template(json);
				exampleValues = parsedTemplate({act:'view'});
				document.getElementById('user_navigation').innerHTML=exampleValues;
				//processUser();
				}
			});

		}
		
	this.Load_User_Page = function()
	{
		
		var parsedTemplate ='';
		var exampleValues = '';
		
		
			$.ajax({
			url:'/Code_Quality_Analysis/User_Page.html',
			type:'GET',
			async: false,
			success: function(json) {

				parsedTemplate = _.template(json);
				exampleValues = parsedTemplate({act:'view'});
				document.getElementById('user_page').innerHTML=exampleValues;
				
				}
			});

	}
	
}