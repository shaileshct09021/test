import os, time, sys
import json
from elasticsearch import Elasticsearch


doc ={"overview" :{"sonar" : ov_rpt["overview"]}, "detailed" : {"sonar" : dt_rpt ,"understand" : understd },"health" : ov_rpt["health"], "timestamp" : time1 }

es = Elasticsearch(["http://10.71.71.18:9200"])

es.index(index="reportstore", doc_type=jobname, id=build_id, body=doc)
