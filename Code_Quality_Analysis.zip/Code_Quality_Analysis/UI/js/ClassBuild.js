function ClassBuild(pname,build_id)
{
	var pname = pname;
	var build_id = build_id;

	this.runBuild = function(){

		console.log('Class'+pname);
		$('#pleaseWaitDialog').modal('show');
		
		var formData = JSON.stringify({jobname : pname});
		
		$.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/buildproject',
					    dataType: 'json',
					    type: 'post',
					    contentType: 'application/json',
					    data: formData,
						success: function(json) {
							//console.log(json['status']);
							document.getElementById('output_div').innerHTML='<div class="alert alert-success"><strong>Success!</strong> Project build will be Added Shortly.</div>';
							$('#pleaseWaitDialog').modal('hide');
							}
					});
	}
	
	this.listBuild = function(){
	
	
				 var getdata ;
				 var start = localStorage.getItem("jobpage_start");
				 var size = localStorage.getItem("page_size");;
				 $.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/getbuilds',
						dataType: 'json',
						type: 'post',
						contentType: 'application/json',
						data: JSON.stringify({jobname:pname,"start": start,"size": size}),
						success: function(jsondata) {
							
							
								$.ajax({
									url:'/Code_Quality_Analysis/view_builds.html',
									type:'GET',
									async: true,
									success: function(json) {

										dataTemplate = _.template(json);
										tempValues = dataTemplate({jobname:pname,build_detail:jsondata});
										document.getElementById("builds_"+pname).innerHTML=tempValues;
										
										}
									});
						}
		
				});
	}

	this.DreportBuild = function(){
		
		
		var formData = JSON.stringify({jobname : pname,build_id : build_id});
		
		var tempValues="";
		var dataTemplate="";
		
		$.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/getreport',
					    dataType: 'json',
					    type: 'post',
					    contentType: 'application/json',
					    data: formData,
						success: function(result) {
							
							console.log('Class');
							$.ajax({
									url:'/Code_Quality_Analysis/view_detail.html',
									type:'GET',
									async: true,
									success: function(json) {

										dataTemplate = _.template(json);
										tempValues = dataTemplate({build_detail:result});
										document.getElementById("output_div").innerHTML=tempValues;
										
										}
									});

							}
					});
	}
	this.OreportBuild = function(){
		
		
		var formData = JSON.stringify({jobname : pname,build_id : build_id});
		
		var tempValues="";
		var dataTemplate="";
		
		$.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/getreport',
					    dataType: 'json',
					    type: 'post',
					    contentType: 'application/json',
					    data: formData,
						success: function(result) {
							
							console.log('Class');
							$.ajax({
									url:'/Code_Quality_Analysis/view_overview.html',
									type:'GET',
									async: true,
									success: function(json) {

										dataTemplate = _.template(json);
										tempValues = dataTemplate({build_detail:result});
										document.getElementById("output_div").innerHTML=tempValues;
										
										}
									});

							}
					});
	}
	
	this.ClassWiseReport = function(){
		
		var formData = JSON.stringify({jobname : pname,build_id : build_id});
		
		var tempValues="";
		var dataTemplate="";
		document.getElementById("output_div").innerHTML='<div class="largeloader" ></div>';
		$.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/gethierarchy',
					    dataType: 'json',
					    type: 'post',
					    contentType: 'application/json',
					    data: formData,
			success: function(data)
			{
				//var result = csvTojs(data);
				
				$.ajax({
									url:'/Code_Quality_Analysis/View_Class_Report.html',
									type:'GET',
									async: true,
									success: function(json) {

										dataTemplate = _.template(json);
										tempValues = dataTemplate({build_detail:data,jobname : pname,build_id : build_id});
										document.getElementById("output_div").innerHTML=tempValues;
										
										}
									});
			}
		});
		
	
	}
	
	this.ClassWiseCompare = function(b1,b2){
		var formData1 = JSON.stringify({jobname : pname,build_id : b2});
		var formData2 = JSON.stringify({jobname : pname,build_id : b1});
		
		var tempValues="";
		var dataTemplate="";
		
		
		$.ajax({
						url: 'http://10.71.71.18:5000/todo/api/v1.0/gethierarchy',
					    dataType: 'json',
					    type: 'post',
					    contentType: 'application/json',
					    data: formData1,
			success: function(data)
			{
				//var result1 = csvTojs(data);
				//var result2 = csvTojs(data);
				
				$.ajax({
									url:'/Code_Quality_Analysis/View_Compare_Report.html',
									type:'GET',
									async: true,
									success: function(json) {

										dataTemplate = _.template(json);
										tempValues = dataTemplate({build1:b2,build2:b1,jobname : pname,pre_build_detail:data});
										document.getElementById("output_div").innerHTML=tempValues;
										
										}
									});
			}
		});
		
		/*$.when(
					$.ajax({ // First Request
						url: 'http://10.71.71.18:5000/todo/api/v1.0/getreport', 
						type: 'post', 
						contentType: 'application/json',
						data: formData1,     
						cache: false,
						success: function(returnhtml){     
								result1 = returnhtml;                  
						}           
					}),

					$.ajax({ //Seconds Request
						url: 'http://10.71.71.18:5000/todo/api/v1.0/getreport', 
						type: 'post', 
						contentType: 'application/json',
						data: formData2,     
						cache: false,
						success: function(returnhtml){                          
							result2 = returnhtml;     
						}           
					})

				).then(function() {
					
								$.ajax({
												url:'/Code_Quality_Analysis/View_Compare_Report.html',
												type:'GET',
												async: true,
												success: function(json) {

													dataTemplate = _.template(json);
													tempValues = dataTemplate({build1:b2,build2:b1,pre_build_detail:result1,curr_build_detail:result2});
													document.getElementById("output_div").innerHTML=tempValues;
													
													}
												});
				});*/
		
	}

}

