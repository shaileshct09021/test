import requests
import json
import csv


# return the result generated from API in json format
def getJasonresult(req_url):
    resp = requests.get(req_url)

    if resp.status_code != 200:
        # This means something went wrong.
        raise ApiError('GET /tasks/ {}'.format(resp.status_code))

    return resp.json()

#Writes json data to a file for further processing
def writeToFile(filename,data):
    string_data = json.dumps(data)

    with open(filename, "w") as f:
        f.write(string_data)

#Reads the result and displays to the user
def readAndStore(filename, json_data):

    json_file_handler = open(filename, "r")

    json_string = json_file_handler.read()

    loaded_json_string = json.loads(json_string)

    for element in loaded_json_string:
        if 'msr' in element:
            json_data = element.get('msr')

    return json_data


def overview_analysis():
    url_req_overview = 'http://10.71.71.18:9000/api/resources?resource=locusfile&metrics=ncloc,code_smells,comment_lines,commented_out_code_lines,classes,files,vulnerabilities,functions,comment_lines_density,duplications_data'
    data_initial = getJasonresult(url_req_overview)
    json_file_handler = "ca_j1.json"
    writeToFile(json_file_handler, data_initial)
    json_string = readAndStore(json_file_handler, json_data={})

    json_string_parsed = json_string


    csv_file_handler = open('overview.csv', 'w')
    csvwriter = csv.writer(csv_file_handler)

    count = 0

    for string_instance in json_string:

      if count == 0:

             header = string_instance.keys()
             header.remove('frmt_val')
            
             csvwriter.writerow(header)

             count += 1
      select_value = string_instance.values()
      select_value.remove(select_value[0])
      
      csvwriter.writerow(select_value)

    csv_file_handler.close()


overview_analysis()
